// boty.js
const API = [
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
    "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"
];

module.exports = { API };