const { Markup } = require('telegraf');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const activeChessGames = new Map();

function getGroqApiKey() {
    try {
        const botyPath = path.resolve(__dirname, '../boty.js');
        if (fs.existsSync(botyPath)) {
            const botyModule = require(botyPath);
            if (botyModule && Array.isArray(botyModule.API) && botyModule.API.length > 0) {
                return botyModule.API[Math.floor(Math.random() * botyModule.API.length)];
            }
        }
    } catch (e) {
        console.error("Error reading boty.js API keys:", e);
    }
    return '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';
}

function setupChessGame(bot) {
    bot.command('htrmnh', async (ctx) => {
        try {
            const userId = ctx.from.id;
            
            const gameState = {
                board: [
                    ['♜', '♞', '♝', '♛', '♚', '♝', '♞', '♜'],
                    ['♟', '♟', '♟', '♟', '♟', '♟', '♟', '♟'],
                    ['➖', '➖', '➖', '➖', '➖', '➖', '➖', '➖'],
                    ['➖', '➖', '➖', '➖', '➖', '➖', '➖', '➖'],
                    ['➖', '➖', '➖', '➖', '➖', '➖', '➖', '➖'],
                    ['➖', '➖', '➖', '➖', '➖', '➖', '➖', '➖'],
                    ['♙', '♙', '♙', '♙', '♙', '♙', '♙', '♙'],
                    ['♖', '♘', '♗', '♕', '♔', '♗', '♘', '♖']
                ],
                turn: 'user',
                userSymbol: '♙',
                aiSymbol: '♟',
                gameOver: false,
                result: null,
                lastClickTime: 0,
                isAiThinking: false,
                stepCount: 0
            };

            activeChessGames.set(userId, gameState);

            await ctx.reply(
                `تم بدا لعبه الشطرنج العب بل ازرار الى تحتك لحد ما تفوز\nهنا ازرار لعبه الشطرنج\n\nدورك للعب (اختر حركة):`,
                getChessKeyboard(gameState.board)
            );

        } catch (error) {
            console.error("Error in htrmnh command:", error);
        }
    });

    bot.action(/chess_move_(.+)/, async (ctx) => {
        try {
            const userId = ctx.from.id;
            const game = activeChessGames.get(userId);

            if (!game) {
                return ctx.answerCbQuery("⚠️ انتهت الجلسة، ابدأ من جديد بـ /htrmnh", { show_alert: true });
            }

            const now = Date.now();
            if (game.isAiThinking || (now - game.lastClickTime < 1000)) {
                return ctx.answerCbQuery("لا تضغط بتنهكني😦🥀", { show_alert: true });
            }
            game.lastClickTime = now;

            if (game.gameOver) {
                if (game.result === 'win') {
                    return ctx.answerCbQuery("لقد فزت يا وحش😹💔", { show_alert: true });
                } else {
                    return ctx.answerCbQuery("خسرت يا واد لا تلعب ثاني 😹💔", { show_alert: true });
                }
            }

            if (game.turn !== 'user') {
                return ctx.answerCbQuery("⚠️ ليس دورك الآن، انتظر دور الـ AI!", { show_alert: true });
            }

            await ctx.answerCbQuery("✅ تم تسجيل حركتك.");
            const moveType = ctx.match[1];

            updateBoardAfterUserMove(game, moveType);
            game.stepCount++;

            const apiKey = getGroqApiKey();
            game.turn = 'ai';
            game.isAiThinking = true;

            await safeEditMessage(
                ctx,
                `جاري تفكير الـ AI في حركة الشطرنج...\n\n${renderChessBoard(game.board)}`,
                getChessKeyboard(game.board)
            );

            await handleChessAiTurn(ctx, userId, apiKey);

        } catch (error) {
            console.error("Error in chess action:", error);
            if (activeChessGames.has(ctx.from.id)) {
                activeChessGames.get(ctx.from.id).isAiThinking = false;
            }
            await ctx.answerCbQuery("حدث خطأ ما، حاول مجدداً.", { show_alert: true }).catch(() => {});
        }
    });
}

function updateBoardAfterUserMove(game, moveType) {
    if (moveType === 'pawn_forward') {
        for (let j = 0; j < 8; j++) {
            if (game.board[6][j] === '♙') {
                game.board[5][j] = '♙';
                game.board[6][j] = '➖';
                break;
            }
        }
    } else if (moveType === 'knight') {
        if (game.board[7][1] === '♘') {
            game.board[5][2] = '♘';
            game.board[7][1] = '➖';
        } else if (game.board[7][6] === '♘') {
            game.board[5][5] = '♘';
            game.board[7][6] = '➖';
        }
    } else {
        for (let i = 6; i >= 4; i--) {
            for (let j = 0; j < 8; j++) {
                if (game.board[i][j] !== '➖' && game.board[i-1][j] === '➖') {
                    game.board[i-1][j] = game.board[i][j];
                    game.board[i][j] = '➖';
                    return;
                }
            }
        }
    }
}

async function handleChessAiTurn(ctx, userId, apiKey) {
    const game = activeChessGames.get(userId);
    if (!game) return;

    try {
        const prompt = `You are playing a simplified Chess game against a human. 
Current board state: ${JSON.stringify(game.board)}
Make your AI move.`;

        const response = await axios.post(
            'https://api.groq.com/openai/v1/chat/completions',
            {
                model: 'llama3-8b-8192',
                messages: [{ role: 'user', content: prompt }],
                temperature: 0.7
            },
            {
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json'
                },
                timeout: 10000
            }
        );

        for (let i = 1; i <= 2; i++) {
            for (let j = 0; j < 8; j++) {
                if (game.board[i][j] !== '➖' && game.board[i+1][j] === '➖') {
                    game.board[i+1][j] = game.board[i][j];
                    game.board[i][j] = '➖';
                    break;
                }
            }
        }

        const isAiWin = game.stepCount >= 5 && Math.random() < 0.3; 
        const isUserWin = game.stepCount >= 4 && Math.random() < 0.3; 

        if (isAiWin) {
            game.gameOver = true;
            game.result = 'lose';
            game.isAiThinking = false;
            await safeEditMessage(
                ctx,
                `♟️ لقد فاز الـ AI عليك في الشطرنج!\n\n${renderChessBoard(game.board)}`,
                getChessKeyboard(game.board)
            );
            return;
        }

        if (isUserWin) {
            game.gameOver = true;
            game.result = 'win';
            game.isAiThinking = false;
            await safeEditMessage(
                ctx,
                `🏆 لقد فزت على الـ AI في الشطرنج يا وحش!\n\n${renderChessBoard(game.board)}`,
                getChessKeyboard(game.board)
            );
            return;
        }

        game.turn = 'user';
        game.isAiThinking = false;
        
        await safeEditMessage(
            ctx,
            `تم تحديث رقعة الشطرنج. دورك الآن:\n\n${renderChessBoard(game.board)}`,
            getChessKeyboard(game.board)
        );

    } catch (e) {
        console.error("Groq Chess API Error:", e.message);
        game.turn = 'user';
        game.isAiThinking = false;
        await safeEditMessage(
            ctx,
            `دورك الآن:\n\n${renderChessBoard(game.board)}`,
            getChessKeyboard(game.board)
        );
    }
}

function getChessKeyboard(board) {
    return Markup.inlineKeyboard([
        [
            Markup.button.callback('♙ تحريك الأمام', 'chess_move_pawn_forward'),
            Markup.button.callback('♘ نقل الحصان', 'chess_move_knight')
        ],
        [
            Markup.button.callback('♗ نقل الفيل', 'chess_move_bishop'),
            Markup.button.callback('♖ نقل القلعة', 'chess_move_rook')
        ],
        [
            Markup.button.callback('♕ نقل الوزير', 'chess_move_queen'),
            Markup.button.callback('♔ تحريك الملك', 'chess_move_king')
        ]
    ]);
}

function renderChessBoard(board) {
    return board.map(row => row.join(' ')).join('\n');
}

async function safeEditMessage(ctx, text, replyMarkup) {
    try {
        await ctx.editMessageText(text, replyMarkup);
    } catch (error) {
        if (!error.message.includes('message is not modified')) {
            console.error("Safe edit message error:", error.message);
        }
    }
}

module.exports = setupChessGame;