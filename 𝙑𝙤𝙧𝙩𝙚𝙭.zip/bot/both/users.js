function setupUsersCommand(bot) {
    bot.command('users', async (ctx) => {
        // يمكنك استبدال هذه الأرقام بالمتغيرات الفعلية من قاعدة البيانات الخاصة بك
        const totalUsers = 15;      // إجمالي عدد المستخدمين
        const onlineUsers = 12;      // المتصلين
        const offlineUsers = 13;    // غير المتصلين

        const text = `╔═━────━❖♛❖━────━═╗
      𓆩مستخدمين البوت𓆪
عدد المستخدمين: ${totalUsers}
المتصلين: ${onlineUsers}
الغير متصلين: ${offlineUsers}
المطور: داكس المظ
╚═━────━❖♛❖━────━═╝`;

        await ctx.reply(text);
    });
}

module.exports = setupUsersCommand;