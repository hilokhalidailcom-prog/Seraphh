// تم التطوير بواسطه داكس المظ🐦مطور بوت سيراف
// لا تحذف السطرين دول بل حب😭🗿

const fs = require('fs');
const path = require('path');
const { Markup } = require('telegraf');

const DB_PATH = path.resolve(__dirname, '../قاعده.json');

// قراءة قاعدة البيانات
function loadDatabase() {
    try {
        if (fs.existsSync(DB_PATH)) {
            const data = fs.readFileSync(DB_PATH, 'utf8');

            if (!data.trim()) {
                return [];
            }

            const jsonData = JSON.parse(data);

            // قاعدة البيانات عبارة عن مصفوفة مباشرة
            return Array.isArray(jsonData)
                ? jsonData
                : [];
        }
    } catch (error) {
        console.error(
            'Error reading قاعده.json:',
            error
        );
    }

    return [];
}

function setupPublicCommands(bot) {

    // فتح القائمة عند إرسال الأمر /rhf
    bot.command('rhf', async (ctx) => {

        try {

            const userId = ctx.from.id;

            // قراءة قاعدة البيانات
            const usersList = loadDatabase();

            // البحث عن المستخدم
            const user = usersList.find(
                user => user.id === userId
            );

            // إذا المستخدم غير موجود
            if (!user) {

                return ctx.reply(
                    '❌ لا يمكنك استخدام هذه القائمة.\n\n' +
                    'يجب عليك التسجيل في البوت أولاً. اكتب "ناهه"  ل يتم تسجيلك'
                );
            }

            // المستخدم موجود، عرض القائمة
            return ctx.reply(
                `مرحبا بك في ارشيف حسابك\n` +
                `معرف حسابك: \`${userId}\``,
                {
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([
                        [
                            Markup.button.callback(
                                'تحويل رصيد',
                                'تحويل'
                            )
                        ],
                        [
                            Markup.button.callback(
                                'معلومات حسابك',
                                'حسابك'
                            )
                        ],
                        [
                            Markup.button.callback(
                                'عجله الحظ',
                                'حظ'
                            )
                        ],
                        [
                            Markup.button.callback(
                                'استخدام الكود',
                                'كود'
                            )
                        ],
                        [
                            Markup.button.callback(
                                'ربح نقاط مجانأ',
                                'احالة'
                            )
                        ]
                    ])
                }
            );

        } catch (error) {

            console.error(
                'Error in /rhf:',
                error
            );

            return ctx.reply(
                '❌ حدث خطأ أثناء فتح القائمة.'
            );
        }
    });

    bot.action('تحويل', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.reply('اكتب\n/transformation');
    });

    bot.action('حسابك', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.reply('اكتب\n/account');
    });

    bot.action('حظ', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.reply('اكتب\n/spin');
    });

    bot.action('كود', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.reply('اكتب\n/Code');
    });

    bot.action('احالة', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.reply('اكتب\n/Referral');
    });
}

module.exports = setupPublicCommands;