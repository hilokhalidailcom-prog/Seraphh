const fs = require('fs');
const path = require('path');

const DB_PATH = path.resolve(__dirname, '../قاعده.json');

function loadDatabase() {
    try {
        if (fs.existsSync(DB_PATH)) {
            const data = fs.readFileSync(DB_PATH, 'utf8');
            const jsonData = JSON.parse(data);

            // الملف عبارة عن مصفوفة مباشرة
            return Array.isArray(jsonData)
                ? jsonData
                : (jsonData.users || []);
        }
    } catch (e) {
        console.error("Error reading قاعده.json:", e);
    }

    return [];
}

function setupAccountCommand(bot) {

    bot.command(['account', 'info', 'معلوماتي'], async (ctx) => {

        try {

            const userId = ctx.from.id;

            const usersList = loadDatabase();

            const userObj = usersList.find(
                user => user.id === userId
            );

            if (!userObj) {
                return ctx.reply(
                    '❌ لم يتم العثور على حسابك في قاعدة البيانات.'
                );
            }

            // تحويل الوقت من milliseconds إلى تاريخ مقروء
            function formatDate(timestamp) {

                if (!timestamp) {
                    return 'غير مسجل';
                }

                return new Date(timestamp).toLocaleString('ar-SA', {
                    timeZone: 'Asia/Riyadh',
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit'
                });
            }

            const accountInfo =
`معلومات حسابك 👤

📝 اسم المستخدم: ${userObj.smi || 'غير مسجل'}

🆔 الايدي: ${userObj.id}

💰 النقاط: ${userObj.points ?? 0}

🔐 كلمة المرور: ${userObj.passage || 'غير مسجلة'}

🌐 اللغة: ${userObj["the language"] || 'غير محددة'}

📅 وقت تسجيل الدخول:
${formatDate(userObj.Login)}

🔄 عدد عمليات التحويل: ${userObj.Conversion ?? 0}

👥 الإحالات: ${
    Array.isArray(userObj.Referral)
        ? userObj.Referral.length
        : 0
}

🛒 عدد المشتريات: ${userObj.Purchase ?? 0}

🕐 آخر ظهور:
${formatDate(userObj["Last appearance"])}`;

            await ctx.reply(accountInfo);

        } catch (error) {

            console.error(
                "Error in account command:",
                error
            );

            await ctx.reply(
                "❌ حدث خطأ أثناء استرجاع معلومات حسابك."
            );
        }
    });
}

module.exports = setupAccountCommand;