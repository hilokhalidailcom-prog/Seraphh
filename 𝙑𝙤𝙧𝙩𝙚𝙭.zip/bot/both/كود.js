const { Markup } = require('telegraf');
const fs = require('fs');
const path = require('path');

// مسار ملف الأكواد
const CODES_DB_PATH = path.resolve(__dirname, '../قاعدة.json');
// مسار ملف المستخدمين (بدون همزة)
const USERS_DB_PATH = path.resolve(__dirname, '../قاعده.json');

const ANNOUNCEMENT_CHANNEL = "-1004413849148";
const ADMIN_ID = 8112442788; // الأيدي الخاص بك كمطور

const activeCodeSessions = new Map();

// دالة قراءة الأكواد (قاعدة.json)
function loadCodesDatabase() {
    try {
        if (fs.existsSync(CODES_DB_PATH)) {
            const rawData = fs.readFileSync(CODES_DB_PATH, 'utf8');
            const data = JSON.parse(rawData);
            return Array.isArray(data) ? data : [];
        }
    } catch (e) {
        console.error("Error reading قاعدة.json:", e);
    }
    return [];
}

// دالة حفظ الأكواد (قاعدة.json)
function saveCodesDatabase(data) {
    try {
        fs.writeFileSync(CODES_DB_PATH, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error("Error saving قاعدة.json:", e);
    }
}

// دالة قراءة المستخدمين (قاعده.json)
function loadUsersDatabase() {
    try {
        if (fs.existsSync(USERS_DB_PATH)) {
            const rawData = fs.readFileSync(USERS_DB_PATH, 'utf8');
            const data = JSON.parse(rawData);
            return Array.isArray(data) ? data : [];
        }
    } catch (e) {
        console.error("Error reading قاعده.json:", e);
    }
    return [];
}

// دالة حفظ المستخدمين (قاعده.json)
function saveUsersDatabase(data) {
    try {
        fs.writeFileSync(USERS_DB_PATH, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error("Error saving قاعده.json:", e);
    }
}

function setupCodeCommands(bot) {

    // 1. أمر المطور لإنشاء كود (يحفظ في قاعدة.json)
    bot.command('generate_code', async (ctx) => {
        if (ctx.from.id !== ADMIN_ID) {
            return ctx.reply("❌ هذا الأمر مخصص للمطورين فقط.");
        }

        const args = ctx.message.text.split(' ');
        const code = args[1];
        const maxUses = parseInt(args[2] || 5);

        if (!code) {
            return ctx.reply("❌ الاستخدام الصحيح:\n`/generate_code <الكود> <عدد_الاستخدامات>`");
        }

        let db = loadCodesDatabase();
        
        if (db.some(c => c.code === code)) {
            return ctx.reply("❌ هذا الكود موجود بالفعل!");
        }

        db.push({ code, maxUses, usedBy: [] });
        saveCodesDatabase(db);

        const msg = `كود نقاط مجانا @Bot_Swirl_Bot   🎁
• الكود : ${code}
• اذهب الى بوت سيراف  🙈
• اضغط استخدام كود يتم شحن النقاط
#شارك رابط الدعوة لاصدقائك لكل شخص يقوم بالدخول ستحصل على 30 نقطه مجاناً 😍`;
        
        try {
            await bot.telegram.sendMessage(ANNOUNCEMENT_CHANNEL, msg);
            await ctx.reply(`✅ تم إنشاء الكود (${code}) ونشره في القناة بنجاح.`);
        } catch (error) {
            await ctx.reply(`❌ فشل النشر في القناة. تأكد من أن البوت **مشرف (Admin)** في القناة.\nالخطأ: ${error.message}`);
        }
    });

    // 2. أمر المستخدم لتفعيل الكود (/Code)
    bot.command('Code', async (ctx) => {
        try {
            activeCodeSessions.set(ctx.from.id, true);
            await ctx.reply("📧 الرجاء إرسال الكود الذي حصلت عليه الآن لتفعيله:", Markup.forceReply());
        } catch (e) {
            console.error("Error in /Code command:", e);
        }
    });

    // استقبال الكود وتحليله
    bot.on('text', async (ctx, next) => {
        try {
            const userId = ctx.from.id;

            if (!activeCodeSessions.has(userId)) {
                return next();
            }

            activeCodeSessions.delete(userId);

            const inputCode = ctx.message.text.trim();
            const userFirstName = ctx.from.first_name || "مستخدم";

            // فحص الكود من ملف (قاعدة.json)
            let codesDb = loadCodesDatabase();
            const codeObj = codesDb.find(c => c.code === inputCode);

            if (!codeObj) {
                return ctx.reply("❌ الكود الذي أدخلته غير صحيح أو غير موجود.");
            }

            if (codeObj.usedBy && codeObj.usedBy.includes(userId)) {
                return ctx.reply("❌ لقد استخدمت هذا الكود مسبقاً ولا يمكنك استخدامه مرة أخرى!");
            }

            if (codeObj.usedBy && codeObj.usedBy.length >= codeObj.maxUses) {
                return ctx.reply("لقد تم استنفاذ الكود😳\nفي المره القادمه حاول تكون سريعاً 🙄");
            }

            // إضافة أو تحديث النقاط في ملف المستخدمين (قاعده.json)
            let usersDb = loadUsersDatabase();
            let userIndex = usersDb.findIndex(u => u.id === userId);
            
            if (userIndex === -1) {
                usersDb.push({ smi: userFirstName, id: userId, points: 30 });
            } else {
                usersDb[userIndex].points = (usersDb[userIndex].points || 0) + 30;
            }
            saveUsersDatabase(usersDb);

            // تحديث قائمة استخدام الكود وحفظها في ملف (قاعدة.json)
            if (!codeObj.usedBy) codeObj.usedBy = [];
            codeObj.usedBy.push(userId);
            saveCodesDatabase(codesDb);

            await ctx.reply("✅ مبروك! تم شحن 30 نقطة إلى حسابك بنجاح. 🥳");

        } catch (error) {
            console.error("Error processing promo code:", error);
            activeCodeSessions.delete(ctx.from.id);
            await ctx.reply("❌ حدث خطأ أثناء تفعيل الكود.");
        }
    });
}

module.exports = setupCodeCommands;