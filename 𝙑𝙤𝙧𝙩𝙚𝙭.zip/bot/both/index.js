// دن تم التطوير بواسطه داكس المظ🐦مطور بوت سيراف
// لا تحذف السطرين دول بل حب😭🗿

const { Telegraf } = require('telegraf');

// الآيدي الخاص بك لاستقبال الرسائل
const MY_ID = '8112442788';

// معرف القناة العامة التي أرسلتها (طلباتي) وآيديه الرقمي
const TARGET_CHANNEL_USERNAME = 'taIabati';
const TARGET_CHANNEL_ID = '-1002245297230';

function setupMonitorCommand(bot) {
    // البوت سيراقب أي رسالة تنشر في القناة
    bot.on('channel_post', async (ctx) => {
        try {
            const chat = ctx.channelPost.chat;
            
            // التحقق مما إذا كانت الرسالة تخص قناة طلباتي
            const isTargetChannel = (chat.username && chat.username.toLowerCase() === TARGET_CHANNEL_USERNAME.toLowerCase()) || 
                                    (chat.id.toString() === TARGET_CHANNEL_ID);

            if (isTargetChannel) {
                // إعادة توجيه الرسالة فوراً إلى الآيدي الخاص بك
                await ctx.telegram.forwardMessage(
                    MY_ID,           
                    chat.id,         
                    ctx.channelPost.message_id 
                );
            }
        } catch (error) {
            console.error("Error forwarding channel post:", error);
        }
    });

    // أمر بسيط للتأكد أن نظام المراقبة يعمل
    bot.command('monitor_status', (ctx) => {
        ctx.reply('✅ نظام مراقبة قناة طلباتي (@taIabati) يعمل بنجاح ويقوم بتحويل الرسائل إليك.');
    });
}

module.exports = setupMonitorCommand;