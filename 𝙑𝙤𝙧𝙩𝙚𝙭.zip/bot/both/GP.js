const axios = require('axios');
const path = require('path');

function setupGroqCommand(bot) {
    bot.command('GP', async (ctx) => {
        const queryText = ctx.message.text.replace('/GP', '').trim();

        if (!queryText) {
            return ctx.reply('⚠️ عذراً، يرجى كتابة السؤال بعد الأمر. مثال:\n/GP كيف اكل بيتزا');
        }

        await ctx.reply('⏳ جاري إرسال السؤال إلى الذكاء الاصطناعي (Groq)...');

        try {
            const botyPath = path.join(__dirname, '..', 'boty.js');
            
            // مسح الكاش لضمان جلب أحدث بيانات الملف
            if (require.cache[require.resolve(botyPath)]) {
                delete require.cache[require.resolve(botyPath)];
            }
            
            const botyData = require(botyPath);

            // استخراج المصفوفة بغض النظر عن طريقة التصدير في ملف boty.js
            let apiList = [];
            if (Array.isArray(botyData)) {
                apiList = botyData;
            } else if (botyData.API && Array.isArray(botyData.API)) {
                apiList = botyData.API;
            } else if (typeof botyData === 'object' && botyData !== null) {
                const foundKey = Object.keys(botyData).find(key => Array.isArray(botyData[key]));
                if (foundKey) {
                    apiList = botyData[foundKey];
                }
            }

            // إضافة المفتاح الخاص بك بشكل مباشر كخيار أول في القائمة لضمان استخدامه
            const customApiKey = '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';
            if (!apiList.includes(customApiKey)) {
                apiList.unshift(customApiKey);
            }

            if (!Array.isArray(apiList) || apiList.length === 0) {
                return ctx.reply('❌ تعذر العثور على مصفوفة المفاتيح.');
            }

            let success = false;
            let answer = '';
            const url = 'https://api.groq.com/openai/v1/chat/completions';

            for (let apiKey of apiList) {
                try {
                    const response = await axios.post(
                        url,
                        {
                            model: 'openai/gpt-oss-120b', // المعرف الدقيق للنموذج المطلوب
                            messages: [{ role: 'user', content: queryText }],
                            temperature: 0.7
                        },
                        {
                            headers: {
                                'Authorization': `Bearer ${apiKey}`,
                                'Content-Type': 'application/json'
                            },
                            timeout: 10000
                        }
                    );

                    answer = response.data.choices[0].message.content;
                    success = true;
                    break;
                } catch (err) {
                    console.log(`Key failed, trying next... Error: ${err.response?.data?.error?.message || err.message}`);
                    continue; 
                }
            }

            if (success) {
                await ctx.reply(answer);
            } else {
                await ctx.reply('❌ عذراً، فشلت جميع مفاتيح الـ API في الاستجابة.');
            }

        } catch (error) {
            console.error('Groq Error:', error.message);
            await ctx.reply('❌ حدث خطأ أثناء الاتصال بالخادم.');
        }
    });
}

module.exports = setupGroqCommand;