const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

module.exports = (bot) => {
    // معرف المطور الخاص بك (أدخل الـ ID الصحيح هنا)
    const ADMIN_ID = 8112442788; 

    bot.command('zip', async (ctx) => {
        // التحقق مما إذا كان المستخدم هو المطور
        if (ctx.from.id !== ADMIN_ID) {
            return ctx.reply('❌ عذراً، هذا الأمر مخصص للمطور فقط.');
        }

        const outputDir = path.join(__dirname, '..'); // المجلد الرئيسي
        const zipPath = path.join(outputDir, 'bot_files.zip');
        
        ctx.reply("⏳ جاري ضغط ملفات البوت...");

        const output = fs.createWriteStream(zipPath);
        const archive = archiver('zip', { zlib: { level: 9 } });

        output.on('close', async () => {
            await ctx.replyWithDocument(
                { source: zipPath, filename: 'احمد.zip' },
                { caption: '✅ **تم ضغط ملفات البوت بنجاح!**' }
            );
            // حذف الملف بعد الإرسال للتنظيف
            fs.unlinkSync(zipPath);
        });

        archive.on('error', (err) => {
            ctx.reply(`❌ خطأ أثناء الضغط: ${err.message}`);
        });

        archive.pipe(output);
        
        // هنا نضيف المجلدات والملفات التي تريد ضغطها (استبعدنا الملف المضغوط نفسه)
        archive.glob('**/*', {
            ignore: ['node_modules/**', 'bot_files.zip', '.git/**']
        });

        archive.finalize();
    });
};