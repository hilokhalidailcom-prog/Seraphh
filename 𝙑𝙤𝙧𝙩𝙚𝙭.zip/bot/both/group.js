const { Markup } = require('telegraf');

module.exports = function(bot) {
    // أمر /group أو أي اسم أمر تحبه
    bot.command('group', (ctx) => {
        ctx.reply(
            'اضغط على الزر أدناه للانضمام إلى القروب:',
            Markup.inlineKeyboard([
                [Markup.button.url('الانضمام للقروب 🚀', 'https://t.me/+r6Ub5O3gCG42NWFk')]
            ])
        );
    });
};