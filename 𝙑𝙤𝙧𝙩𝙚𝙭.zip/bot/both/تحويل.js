 // تم التطوير بواسطه داكس المظ🐦مطور بوت سيراف
// لا تحذف السطرين دول بل حب😭🗿

const fs = require('fs');
const path = require('path');
const { Markup } = require('telegraf');

const DB_PATH = path.resolve(__dirname, '../قاعده.json');

// دالة لقراءة قاعدة البيانات
function loadDatabase() {
    try {
        if (fs.existsSync(DB_PATH)) {
            const data = fs.readFileSync(DB_PATH, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error("Error reading قاعده.json:", e);
    }
    return [];
}

// دالة لحفظ قاعدة البيانات
function saveDatabase(data) {
    try {
        fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error("Error saving قاعده.json:", e);
    }
}

function setupTransformationCommand(bot) {
    // خريطة لتتبع خطوات التحويل لكل مستخدم
    const transferSteps = new Map();

    // 1. بدء الأمر
    bot.command('transformation', (ctx) => {
        const userId = ctx.from.id;

        transferSteps.set(userId, {
            step: 'WAITING_FOR_ID'
        });

        ctx.reply('🔹 أرسل ايدي المستخدم (ID) المراد التحويل إليه:');
    });

    // 2. استقبال المدخلات النصية
    bot.on('text', async (ctx, next) => {
        const userId = ctx.from.id;

        if (!transferSteps.has(userId)) {
            return next();
        }

        const state = transferSteps.get(userId);
        const text = ctx.message.text.trim();

        // الخطوة الأولى: استقبال ID المستلم
        if (state.step === 'WAITING_FOR_ID') {

            const receiverId = parseInt(text);

            if (isNaN(receiverId)) {
                return ctx.reply(
                    '❌ ايدي غير صحيح. الرجاء إرسال رقم ايدي صحيح فقط.'
                );
            }

            if (receiverId === userId) {
                transferSteps.delete(userId);

                return ctx.reply(
                    '❌ لا يمكنك تحويل نقاط لنفسك!'
                );
            }

            const usersList = loadDatabase();

            const receiverUser = usersList.find(
                u => u.id === receiverId
            );

            if (!receiverUser) {
                transferSteps.delete(userId);

                return ctx.reply(
                    '❌ المستخدم غير موجود في قاعدة البيانات.'
                );
            }

            // حفظ ID المستلم
            state.receiverId = receiverId;
            state.step = 'WAITING_FOR_AMOUNT';

            transferSteps.set(userId, state);

            return ctx.reply(
                '✅ تم العثور على المستخدم.\n\n' +
                '🔹 الآن أرسل المبلغ المراد تحويله (رقم صحيح):'
            );
        }

        // الخطوة الثانية: استقبال المبلغ
        if (state.step === 'WAITING_FOR_AMOUNT') {

            const amount = parseInt(text);

            if (isNaN(amount) || amount <= 0) {
                return ctx.reply(
                    '❌ الرجاء إرسال مبلغ صحيح وموجب.'
                );
            }

            const usersList = loadDatabase();

            const senderIndex = usersList.findIndex(
                u => u.id === userId
            );

            if (
                senderIndex === -1 ||
                usersList[senderIndex].points < amount
            ) {
                const currentPoints =
                    senderIndex !== -1
                        ? usersList[senderIndex].points
                        : 0;

                transferSteps.delete(userId);

                return ctx.reply(
                    `❌ رصيدك غير كافي لإتمام التحويل.\n` +
                    `رصيدك الحالي: ${currentPoints} نقطة.`
                );
            }

            // حفظ المبلغ
            state.amount = amount;

            // إنهاء الجلسة المؤقتة
            transferSteps.delete(userId);

            // تجهيز الوقت
            const now = new Date();

            const timeString = now.toLocaleString('ar-EG', {
                timeZone: 'Asia/Riyadh',
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });

            state.timeString = timeString;

            // رسالة التأكيد
            const confirmMessage =
                `تاكيد عمليه التحويل\n` +
                `المبلغ المحول: ${amount}\n` +
                `المستلم: ${state.receiverId}\n` +
                `الوقت: ${timeString}\n\n` +
                `يرجى تاكيد عمليه التحويل`;

            return ctx.reply(
                confirmMessage,
                Markup.inlineKeyboard([
                    [
                        Markup.button.callback(
                            'تاكيد التحويل',
                            `confirm_tx_${state.receiverId}_${amount}`
                        ),
                        Markup.button.callback(
                            'الغاء',
                            'cancel_tx'
                        )
                    ]
                ])
            );
        }

        return next();
    });

    // 3. إلغاء التحويل
    bot.action('cancel_tx', async (ctx) => {

        await ctx.answerCbQuery();

        await ctx.editMessageText(
            '❌ تم إلغاء عملية التحويل.'
        );
    });

    // 4. تأكيد التحويل
    bot.action(
        /^confirm_tx_(\d+)_(\d+)$/,
        async (ctx) => {

            await ctx.answerCbQuery();

            const senderId = ctx.from.id;

            const receiverId =
                parseInt(ctx.match[1]);

            const amount =
                parseInt(ctx.match[2]);

            let usersList = loadDatabase();

            // البحث عن المرسل
            const senderIndex =
                usersList.findIndex(
                    u => u.id === senderId
                );

            // فحص الرصيد مرة أخرى
            if (
                senderIndex === -1 ||
                usersList[senderIndex].points < amount
            ) {
                return ctx.editMessageText(
                    '❌ عذراً، رصيدك أصبح غير كافي لإتمام هذه العملية.'
                );
            }

            // البحث عن المستلم
            let receiverIndex =
                usersList.findIndex(
                    u => u.id === receiverId
                );

            if (receiverIndex === -1) {
                return ctx.editMessageText(
                    '❌ المستخدم غير موجود في قاعدة البيانات.'
                );
            }

            // تنفيذ التحويل
            usersList[senderIndex].points -= amount;

            usersList[receiverIndex].points += amount;

            // ==========================================
            // تسجيل عملية التحويل
            // ==========================================

            // إذا لم تكن الخاصية موجودة
            if (
                typeof usersList[senderIndex].Conversion !== 'number'
            ) {
                usersList[senderIndex].Conversion = 0;
            }

            // زيادة عدد عمليات التحويل بمقدار 1
            usersList[senderIndex].Conversion += 1;

            // حفظ قاعدة البيانات
            saveDatabase(usersList);

            const senderName =
                ctx.from.first_name || 'مستخدم';

            // تعديل رسالة المرسل
            await ctx.editMessageText(
                `✅ تم التحويل بنجاح.\n\n` +
                `➖ تم خصم ${amount} نقطة من رصيدك.\n` +
                `➕ تم تحويلها إلى ${receiverId}.\n\n` +
                `🔄 عدد عمليات التحويل الخاصة بك: ` +
                `${usersList[senderIndex].Conversion}`
            );

            // إرسال رسالة للمستلم
            try {

                await bot.telegram.sendMessage(
                    receiverId,
                    `➕ تم شحن ${amount} نقطة إلى حسابك ✅.\n` +
                    `➖ تم الشحن من قِبل ${senderName} ♻️.`
                );

            } catch (e) {

                console.log(
                    "Could not send DM to receiver:",
                    e.message
                );
            }
        }
    );
}

module.exports = setupTransformationCommand;