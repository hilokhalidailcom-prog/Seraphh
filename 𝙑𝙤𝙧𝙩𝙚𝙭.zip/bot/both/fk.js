const { Markup } = require('telegraf');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const activeUnbanSessions = new Map();
const TARGET_CHANNEL_ID = "-1004457851009";
const DB_PATH = path.resolve(__dirname, '../قاعده.json');

// دالة لقراءة قاعدة البيانات
function loadDatabase() {
    try {
        if (fs.existsSync(DB_PATH)) {
            const data = fs.readFileSync(DB_PATH, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error("Error reading قاعده.json:", e);
    }
    return [];
}

// دالة لحفظ قاعدة البيانات
function saveDatabase(data) {
    try {
        fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error("Error saving قاعده.json:", e);
    }
}

function getRandomApiKey() {
    try {
        const botyPath = path.resolve(__dirname, '../boty.js');
        if (fs.existsSync(botyPath)) {
            const botyModule = require(botyPath);
            if (botyModule && Array.isArray(botyModule.API) && botyModule.API.length > 0) {
                return botyModule.API[Math.floor(Math.random() * botyModule.API.length)];
            }
        }
    } catch (e) {
        console.error("Error reading boty.js API keys:", e);
    }
    return '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';
}

function setupUnbanCommand(bot) {
    bot.command('fk', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const usersList = loadDatabase();
            
            // 1. التحقق من وجود المستخدم وعدد نقاطه (أقل من 7 نقاط)
            const userIndex = usersList.findIndex(user => user.id === userId);
            if (userIndex === -1 || usersList[userIndex].points < 7) {
                return ctx.reply("ليس معك نقاط");
            }

            // حفظ الجلسة إذا كان يملك نقاطاً كافية
            activeUnbanSessions.set(userId, { step: 'waiting_for_phone' });

            await ctx.reply(
                `ارسل الرقم ل فك التبنيد`,
                Markup.forceReply()
            );
        } catch (error) {
            console.error("Error in /fk command:", error);
        }
    });

    bot.on('text', async (ctx, next) => {
        try {
            const userId = ctx.from.id;
            const session = activeUnbanSessions.get(userId);

            if (!session) {
                return next();
            }

            // تحقق إضافي سريع من النقاط قبل بدء التنفيذ لمنع أي تلاعب
            let usersList = loadDatabase();
            let userIndex = usersList.findIndex(user => user.id === userId);
            if (userIndex === -1 || usersList[userIndex].points < 7) {
                activeUnbanSessions.delete(userId);
                return ctx.reply("ليس معك نقاط");
            }

            const phoneNumber = ctx.message.text.trim();
            activeUnbanSessions.delete(userId);

            // 2. إرسال رسالة تأكيد الدفع فوراً قبل بدء التنفيذ
            await ctx.reply("تم تاكيد الدفع لايوجد تراجع");

            await ctx.reply(`⏳ جاري التواصل مع سيرفرات الـ AI وتوليد رسالة فك الحظر باللغة الروسية للرقم: ${phoneNumber} ...`);

            const apiKey = getRandomApiKey();

            const prompt = `You are a helpful assistant. Write a formal appeal email in Russian language to WhatsApp Support to unban this phone number: ${phoneNumber}.
Provide the output in this exact format without any extra markdown formatting if possible:
SUBJECT: [Write Russian subject here]
MESSAGE: [Write Russian email body here including the phone number]`;

            // في حال حدثت مشكلة هنا (قبل نجاح العملية)، لن يتم خصم النقاط لأن الكود سينتقل إلى catch أو يتوقف
            const response = await axios.post(
                'https://api.groq.com/openai/v1/chat/completions',
                {
                    model: 'llama-3.3-70b-versatile',
                    messages: [{ role: 'user', content: prompt }],
                    temperature: 0.7
                },
                {
                    headers: {
                        'Authorization': `Bearer ${apiKey}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 20000
                }
            );

            const aiText = response.data.choices[0].message.content.trim();
            
            let subject = `Разблокировка аккаунта WhatsApp ${phoneNumber}`;
            let message = aiText;

            if (aiText.includes('SUBJECT:') && aiText.includes('MESSAGE:')) {
                const parts = aiText.split('MESSAGE:');
                subject = parts[0].replace('SUBJECT:', '').trim();
                message = parts[1].trim();
            }

            const formattedOutput = 
`الموضوع
ــــــــــــــــــــــــــــــــــــــ
${subject}
ــــــــــــــــــــــــــــــــــــ
الرساله
ـــــــــــــــــــــــــــــــــــ
${message}
ــــــــــــــــــــــــــــــــــــ`;

            await ctx.reply(formattedOutput);

            // 3. تمت العملية بنجاح كامل، الآن فقط نقوم بخصم 7 نقاط وحفظ الملف
            usersList[userIndex].points -= 7;
            saveDatabase(usersList);

            // تجهيز البيانات وإرسال الإشعار للقناة المحددة
            const username = ctx.from.username ? `@${ctx.from.username}` : (ctx.from.first_name || "مستخدم");
            const currentTime = new Date().toLocaleString('ar-SA', { timeZone: 'Asia/Riyadh' });

            const channelNotification = `༺━━━━━━━━━━━━༻\n` +
                                        `تم اكمال طلب بنجاح√\n` +
                                        `الطلب:فك باند رقم\n` +
                                        `العضو:${username} \n` +
                                        `الوقت:${currentTime}\n` +
                                        `نشكركم ل استخدام بوت سيراف\n` +
                                        `༺━━━━━━━━━━━━༻`;

            await bot.telegram.sendMessage(TARGET_CHANNEL_ID, channelNotification, { parse_mode: 'HTML' });

        } catch (error) {
            console.error("Error generating unban appeal:", error.response?.data || error.message);
            activeUnbanSessions.delete(ctx.from.id);
            // لو حصلت مشكلة أثناء التنفيذ، لا يتم خصم النقاط نهائياً
            await ctx.reply(`❌ حدث خطأ أثناء الاتصال بالـ API، ولم يتم خصم أي نقاط منك:\n${error.response?.data?.error?.message || error.message}`);
        }
    });
}

module.exports = setupUnbanCommand;