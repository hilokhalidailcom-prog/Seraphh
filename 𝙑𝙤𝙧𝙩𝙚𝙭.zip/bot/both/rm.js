// تم التطوير بواسطه داكس المظ🐦مطور بوت سيراف
// لا تحذف السطرين دول بل حب😭🗿

const Groq = require('groq-sdk');
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');

const DB_PATH = path.resolve(__dirname, '../قاعده.json');

// دالة لقراءة قاعدة البيانات
function loadDatabase() {
    try {
        if (fs.existsSync(DB_PATH)) {
            const data = fs.readFileSync(DB_PATH, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error("Error reading قاعده.json:", e);
    }
    return [];
}

// دالة لحفظ قاعدة البيانات
function saveDatabase(data) {
    try {
        fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error("Error saving قاعده.json:", e);
    }
}

function setupUnbanCommand(bot) {
    const activeUnbanRequests = new Map();
    const CHANNEL_ID = '-1004457851009'; // معرف القناة

    // تهيئة Groq API
    const groq = new Groq({ apiKey: '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' });

    // تهيئة مرسل البريد الإلكتروني (Nodemailer) باستخدام Gmail و App Password
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'hilokhalidail.com@gmail.com',
            pass: 'ccya wxwr dtow uqxu'
        }
    });

    bot.command('rm', (ctx) => {
        const userId = ctx.from.id;
        const usersList = loadDatabase();

        // 1. فحص قاعدة البيانات والنقاط (يشترط 10 نقاط على الأقل)
        const userIndex = usersList.findIndex(user => user.id === userId);
        if (userIndex === -1 || usersList[userIndex].points < 10) {
            return ctx.reply("ليس معك نقاط");
        }

        activeRequestsCleanup(userId);
        activeUnbanRequests.set(userId, true);
        ctx.reply('ارسل الرقم ل فك حظره');
    });

    bot.use(async (ctx, next) => {
        if (ctx.message?.text && activeUnbanRequests.has(ctx.from.id)) {
            const userId = ctx.from.id;
            
            // فحص إضافي سريع للنقاط قبل البدء
            let usersList = loadDatabase();
            let userIndex = usersList.findIndex(user => user.id === userId);
            if (userIndex === -1 || usersList[userIndex].points < 10) {
                activeUnbanRequests.delete(userId);
                return ctx.reply("ليس معك نقاط");
            }

            const phoneNumber = ctx.message.text.trim();
            const username = ctx.from.username ? `@${ctx.from.username}` : (ctx.from.first_name || 'مستخدم');

            activeUnbanRequests.delete(userId);

            if (!phoneNumber.startsWith('+') || phoneNumber.length < 8) {
                return ctx.reply('❌ الرقم غير صحيح. تأكد من كتابة رمز الدولة متبوعاً بالرقم (مثال: `+9665xxxxxxxx`). أرسل الأمر `/rm` مرة أخرى.');
            }

            // 2. إرسال رسالة تأكيد الدفع فوراً قبل تنفيذ الطلب
            await ctx.reply("تم تاكيد الدفع لايوجد تراجع");

            let progressMsg = await ctx.reply('⏳ جارٍ توليد صياغة الطلب باللغة الروسية عبر الذكاء الاصطناعي...\n`[██░░░░░░░░] 20%`', { parse_mode: 'Markdown' });

            try {
                // 3. استخدام Groq API مع نموذج GPT OSS 120B مع حماية تامة للرد
                const chatCompletion = await groq.chat.completions.create({
                    messages: [
                        {
                            role: "system",
                            content: "You are a helpful assistant. Output must be valid JSON with two keys: 'subject' and 'body' in Russian language for WhatsApp unban request."
                        },
                        {
                            role: "user",
                            content: `Generate an unban request email in Russian for WhatsApp support regarding phone number ${phoneNumber}. Return strictly a JSON object with 'subject' and 'body' keys.`
                        }
                    ],
                    model: "openai/gpt-oss-120b",
                    response_format: { type: "json_object" }
                });

                let emailSubject = `Request to unban phone number ${phoneNumber}`;
                let emailBody = `Hello WhatsApp Support, my number ${phoneNumber} has been banned by mistake, please unban it.`;

                try {
                    const rawContent = chatCompletion.choices[0]?.message?.content || '{}';
                    const aiResponse = JSON.parse(rawContent);
                    if (aiResponse.subject) emailSubject = aiResponse.subject;
                    if (aiResponse.body) emailBody = aiResponse.body;
                } catch (parseErr) {
                    console.log("JSON parse fallback used:", parseErr.message);
                }

                await ctx.telegram.editMessageText(
                    ctx.chat.id,
                    progressMsg.message_id,
                    undefined,
                    '⏳ جارٍ إرسال البريد الإلكتروني إلى دعم واتساب...\n`[██████░░░░] 60%`',
                    { parse_mode: 'Markdown' }
                ).catch(() => {});

                // 4. إرسال الرسالة عبر البريد الإلكتروني إلى دعم واتساب
                const mailOptions = {
                    from: 'hilokhalidail.com@gmail.com',
                    to: 'support@whatsapp.com',
                    subject: emailSubject,
                    text: `Номер, который вы хотите разблокировать  ${phoneNumber}\n\n${emailBody}`
                };

                await transporter.sendMail(mailOptions);

                await ctx.telegram.editMessageText(
                    ctx.chat.id,
                    progressMsg.message_id,
                    undefined,
                    '⏳ بانتظار رد دعم واتساب على البريد...\n`[██████████] 90%`',
                    { parse_mode: 'Markdown' }
                ).catch(() => {});

                // 5. تمت العملية بنجاح كامل، الآن نقوم بخصم 10 نقاط وحفظها في قاعده.json
                usersList[userIndex].points -= 10;
                saveDatabase(usersList);

                await ctx.telegram.editMessageText(
                    ctx.chat.id,
                    progressMsg.message_id,
                    undefined,
                    `✅ تم ارسال الرساله ل دعم واتساب على الايميل وتم خصم 10 نقاط. (رصيدك الحالي: ${usersList[userIndex].points})`,
                    { parse_mode: 'Markdown' }
                ).catch(() => {});

                // إرسال رسالة التأكيد إلى القناة (مع حماية تامة لكي لا تتوقف العملية لو لم يكن البوت مشرفاً)
                try {
                    const now = new Date();
                    const timeString = now.toLocaleString('ar-EG', { 
                        timeZone: 'Asia/Riyadh',
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit'
                    });

                    const channelMessage = `༺━━━━━━━━━━━━༻\n` +
                                            `تم اكمال طلب بنجاح√\n` +
                                            `الطلب:فك حظر\n` +
                                            `الوصف:فك حظر رقم ({خصوصيه})\n` +
                                            `المستخدم:{للاسف لا}\n` +
                                            `الوقت:${timeString}\n` +
                                            `نشكركم ل استخدام بوت سيراف🥀\n` +
                                            `༺━━━━━━━━━━━━༻`;

                    await ctx.telegram.sendMessage(CHANNEL_ID, channelMessage, { parse_mode: 'HTML' });
                } catch (channelErr) {
                    console.log("Channel send notice failed (Bot might not be admin):", channelErr.message);
                }

            } catch (error) {
                await ctx.telegram.deleteMessage(ctx.chat.id, progressMsg.message_id).catch(() => {});
                // لو حدثت أي مشكلة أثناء المعالجة، لن يتم خصم النقاط نهائياً
                await ctx.reply(`❌ حدث خطأ أثناء المعالجة، ولم يتم خصم أي نقاط منك: ${error.message}`);
            }
        } else {
            return next();
        }
    });

    function activeRequestsCleanup(userId) {
        activeUnbanRequests.delete(userId);
    }
}

module.exports = setupUnbanCommand;