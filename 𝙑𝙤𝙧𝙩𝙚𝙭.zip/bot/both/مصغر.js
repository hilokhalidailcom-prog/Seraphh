// تم التطوير بواسطه داكس المظ🐦مطور بوت سيراف
// لا تحذف السطرين دول بل حب😭🗿

const { Markup } = require('telegraf');

function setupMiniAppCommand(bot) {
    bot.command(['app', 'panel', 'تطبيق'], (ctx) => {
        // ضع هنا رابط الـ Web App الخاص بك (سواء كان رابط استضافتك مثل Spark أو صفحة تحكم ويب)
        const webAppUrl = 'https://whatifs.fun/?utm_source=chatgpt.com'; // يمكنك استبداله برابط موقعك أو لوحة التحكم

        return ctx.reply(
            '🌟 **مرحباً بك في لوحة تحكم بوت سيراف المصغرة** 🌟\n\n' +
            '📱 انقر على الزر أدناه لفتح التطبيق المصغر، حيث يمكنك كتابة وتنفيذ الأوامر بسهولة تامة داخل واجهة تفاعلية.',
            {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [Markup.button.webApp('🚀 فتح التطبيق المصغر', webAppUrl)]
                ])
            }
        );
    });
}

module.exports = setupMiniAppCommand;