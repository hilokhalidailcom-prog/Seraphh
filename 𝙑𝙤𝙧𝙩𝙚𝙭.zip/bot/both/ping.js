function setupPingCommand(bot) {
    // أمر البينج لقياس سرعة الاستجابة
    bot.command('ping', async (ctx) => {
        const start = Date.now();
        // إرسال رسالة مؤقتة لحساب وقت الاستجابة
        const sentMessage = await ctx.reply('🏓 جاري قياس السرعة...');
        const latency = Date.now() - start;

        // تعديل الرسالة بالنتيجة النهائية
        await ctx.telegram.editMessageText(
            ctx.chat.id,
            sentMessage.message_id,
            undefined,
            `🏓 Pong!\n⚡ سرعة الاستجابة: ${latency}ms`
        );
    });
}

module.exports = setupPingCommand;