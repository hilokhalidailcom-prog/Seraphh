// دن تم التطوير بواسطه داكس المظ🐦مطور بوت سيراف
// لا تحذف السطرين دول بل حب😭🗿

const { Telegraf } = require('telegraf');

const bot = new Telegraf('8960203963:AAF2JMdfSLqfKVaBufPO9bhFN3tUDE6SUyA');
const ADMIN_GROUP_ID = '-1004447329992';

bot.command('g', async (ctx) => {
    try {
        const text = ctx.message.text.split(' ').slice(1).join(' ');
        if (!text) {
            return ctx.reply("❌ يرجى كتابة المشكلة بعد الأمر، مثل:\n/g مشكلتي هي كذا");
        }

        const user = ctx.from;
        // تصميم الرسالة كنص عادي بدون أي رموز قد تسبب خطأ في الماركداون
        const msg = 
`📩 شكوى دعم فني جديدة:

👤 الاسم: ${user.first_name || 'بدون'} ${user.last_name || ''}
🔗 المعرف: ${user.username ? '@' + user.username : 'لا يوجد'}
🆔 الآيدي: ${user.id}

💬 نص المشكلة:
${text}`;

        // إرسال الرسالة كنص عادي بدون parse_mode لتجنب أي أخطاء
        await bot.telegram.sendMessage(ADMIN_GROUP_ID, msg);
        
        await ctx.reply("✅ تم إرسال شكواك إلى الإدارة بنجاح.");
    } catch (err) {
        console.error("Error in /g command:", err);
        await ctx.reply("❌ حدث خطأ أثناء إرسال الشكوى، حاول مرة أخرى لاحقاً.");
    }
});

bot.start((ctx) => {
    ctx.reply("مرحباً بك! لإرسال مشكلتك للإدارة، استخدم الأمر:\n`/g` متبوعاً بمشكلتك.");
});

bot.launch().then(() => console.log("Bot started successfully."));

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
