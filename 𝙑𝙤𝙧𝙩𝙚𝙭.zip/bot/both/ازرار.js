// تم التطوير بواسطه داكس المظ🐦مطور بوت سيراف
// لا تحذف السطرين دول بل حب😭🗿
const { Markup } = require('telegraf');

function setupPublicCommands(bot) {
    bot.start((ctx) => {
        return ctx.reply(
            '🌟 **مرحباً بك في بوت سيراف** 🌟\n\n' +
            '✨ اختر ما يناسبك من القائمة التفاعلية أدناه:\n' +
            '🔹 *للمساعدة والدعم الفني:* @SeraphBotisaverytbot\n\n' +
            '💫 *استمتع بتجربة فريدة مع بوتنا المتطور*',
            {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [
                        Markup.button.callback('ℹ️ معلومات البوت', 'info'),
                        Markup.button.callback('🆘 المساعدة', 'help')
                    ],
                    [
                        Markup.button.callback('📞 الدعم الفني', 'support')
                    ],
                    [
                        Markup.button.url('📢 قناة التليجرام', 'https://t.me/SeraphOfficial')
                    ],
                    [
                        Markup.button.callback('⚡ اختبار', 'send_auto_text'),
                        Markup.button.callback('🚀 𝙎𝙀𝙍𝘼𝙁', 'send_auto_texty')
                    ],
                    [
                        Markup.button.callback('📶 بينج ☝', 'dax'),
                        Markup.button.callback('👥 المستخدمين', 'send_auto_txt')
                    ],
                    [
                        Markup.button.callback('🎯 بوت 𝙎𝙀𝙍𝘼𝙁', 'send_auto_tzt'),
                        Markup.button.callback('🔊 ازعاج', 'action_name')
                    ],
                    [
                        Markup.button.callback('🤖 اسأل اغبى AI', 's'),
                        Markup.button.callback('📱 ارقام وهمية', 'g')
                    ],
                    [
                        Markup.button.callback('🎮 العب XO', 'ac'),
                        Markup.button.callback('➕ ضيفني لقروبك', 'main')
                    ],
                    [
                        Markup.button.callback('📂 سحب ملفات المواقع', 'MOK')
                    ],
                    [
                        Markup.button.callback('🔓 فك حظر رقم', 'شنق'),
                        Markup.button.callback('♟️ العب شطرنج', 'شطرنج')
                    ],
                    [
                        Markup.button.callback('🔐 فك باند رقم', 'باند')
                    ],
                    [
                        Markup.button.callback('🔄 تشغيل بوت فرعي', 'فرعي'),
                        Markup.button.callback('🔍 اكتشاف ثغرات', 'Gaps')
                    ],
                    [
                        Markup.button.callback('🔑 تخمين كلمات المرور', 'guess'),
                        Markup.button.callback('👤 حسابي', 'حسابي')
                    ]
                ])
            }
        );
    });

    // الاستجابة لضغطات الأزرار
    bot.action('info', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('📌 <b>معلومات البوت</b>\n\n' +
        '🤖 هذا بوت تيليجرام متطور يعمل بنظامين للأوامر.\n' +
        '💡 مصمم لتقديم تجربة مميزة ومتكاملة للمستخدمين.');
    });

    bot.action('help', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('📖 <b>قائمة المساعدة</b>\n\n' +
        '🔹 <code>/start</code> - بدء البوت\n' +
        '🔹 <code>/help</code> - عرض المساعدة\n' +
        '🔹 <code>/dev</code> - معلومات المطور\n' +
        '🔹 <code>/group</code> - معلومات المجموعة\n' +
        '🔹 <code>/ping</code> - اختبار سرعة البوت');
    });

    bot.action('support', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('🛠️ <b>الدعم الفني</b>\n\n' +
        '📞 للتواصل مع الدعم الفني:\n' +
        '👤 @SeraphBotisaverytbot\n\n' +
        '⏳ سيتم الرد عليك في أقرب وقت.');
    });

    bot.action('send_auto_text', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('⚡ <b>اختبار البوت</b>\n\n' +
        '📝 لاستخدام هذه الميزة اكتب:\n' +
        '<code>/dev</code>');
    });

    bot.action('send_auto_texty', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('🚀 <b>بوت 𝙎𝙀𝙍𝘼𝙁</b>\n\n' +
        '💫 لاستخدام هذه الميزة اكتب:\n' +
        '<code>/group</code>');
    });

    bot.action('dax', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('📶 <b>اختبار البينج</b>\n\n' +
        '🔄 لقياس سرعة الاستجابة اكتب:\n' +
        '<code>/ping</code>');
    });

    bot.action('send_auto_txt', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('👥 <b>المستخدمين</b>\n\n' +
        '📊 لعرض إحصائيات المستخدمين اكتب:\n' +
        '<code>/users</code>');
    });

    bot.action('send_auto_tzt', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('🎯 <b>بوت 𝙎𝙀𝙍𝘼𝙁</b>\n\n' +
        '📦 لاستخدام هذه الميزة اكتب:\n' +
        '<code>/getzip</code>');
    });

    bot.action('action_name', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('🔊 <b>ميزة الازعاج</b>\n\n' +
        '🔗 لاستخدام هذه الميزة اكتب:\n' +
        '<code>/link</code>');
    });

    bot.action('s', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('🤖 <b>اسأل اغبى AI</b>\n\n' +
        '💬 لاستخدام الذكاء الاصطناعي اكتب:\n' +
        '<code>/GP</code>\n\n' +
        '⚠️ <i>ملاحظة: هذا الذكاء اصطناعي فكاهي</i>');
    });

    bot.action('g', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('📱 <b>أرقام وهمية</b>\n\n' +
        '🔢 لإنشاء أرقام وهمية اكتب:\n' +
        '<code>/fakenums</code>');
    });

    bot.action('ac', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('🎮 <b>لعبة XO</b>\n\n' +
        '❌⭕ لبدء لعبة إكس أو اكتب:\n' +
        '<code>/xo</code>');
    });

    bot.action('main', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('➕ <b>إضافة البوت</b>\n\n' +
        '👥 لإضافة البوت إلى مجموعتك اكتب:\n' +
        '<code>/add</code>');
    });

    bot.action('MOK', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('📂 <b>سحب ملفات المواقع</b>\n\n' +
        '🌐 لسحب ملفات المواقع اكتب:\n' +
        '<code>/MOK</code>');
    });

    bot.action('شنق', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('🔓 <b>فك حظر رقم</b>\n\n' +
        '📱 لإزالة الحظر عن رقم اكتب:\n' +
        '<code>/rm</code>');
    });

    bot.action('شطرنج', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('♟️ <b>لعبة الشطرنج</b>\n\n' +
        '🎯 لبدء لعبة الشطرنج اكتب:\n' +
        '<code>/htrmnh</code>');
    });

    bot.action('باند', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('🔐 <b>فك باند رقم</b>\n\n' +
        '📱 لإزالة الباند عن رقم اكتب:\n' +
        '<code>/fk</code>');
    });

    bot.action('فرعي', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('🔄 <b>البوت الفرعي</b>\n\n' +
        '⚠️ هذا الأمر قيد التطوير والإصلاح\n' +
        '🛠️ سيتم تفعيله قريباً');
    });

    bot.action('Gaps', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('🔍 <b>اكتشاف الثغرات</b>\n\n' +
        '🔎 لاستخدام أداة اكتشاف الثغرات اكتب:\n' +
        '<code>/sry</code>');
    });

    bot.action('guess', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.replyWithHTML('🔑 <b>تخمين كلمات المرور</b>\n\n' +
        '🔐 لاستخدام أداة تخمين كلمات المرور اكتب:\n' +
        '<code>/brute</code>');
    });

    bot.action('حسابي', async (ctx) => {
        await ctx.answerCbQuery();
        await ctx.reply('اكتب\n/rhf');
    });
}

module.exports = setupPublicCommands;