const { Markup } = require('telegraf');
const axios = require('axios');
const cheerio = require('cheerio');

const userSessions = new Map();
const GROUP_ID = '-1001234567890'; // ضع هنا معرف القروب
const GROUP_LINK = 'https://t.me/seraf198';

// قائمة الدول مع رموز الاتصال
const COUNTRIES = [
    { key: 'united-kingdom', name: '🇬🇧 المملكة المتحدة', link: 'https://anonymsms.com/united-kingdom', code: '+44' },
    { key: 'united-states', name: '🇺🇸 الولايات المتحدة', link: 'https://anonymsms.com/united-states', code: '+1' },
    { key: 'australia', name: '🇦🇺 أستراليا', link: 'https://anonymsms.com/australia', code: '+61' },
    { key: 'canada', name: '🇨🇦 كندا', link: 'https://anonymsms.com/canada', code: '+1' },
    { key: 'sweden', name: '🇸🇪 السويد', link: 'https://anonymsms.com/sweden', code: '+46' },
    { key: 'germany', name: '🇩🇪 ألمانيا', link: 'https://anonymsms.com/germany', code: '+49' },
    { key: 'france', name: '🇫🇷 فرنسا', link: 'https://anonymsms.com/france', code: '+33' },
    { key: 'italy', name: '🇮🇹 إيطاليا', link: 'https://anonymsms.com/italy', code: '+39' },
    { key: 'spain', name: '🇪🇸 إسبانيا', link: 'https://anonymsms.com/spain', code: '+34' },
    { key: 'netherlands', name: '🇳🇱 هولندا', link: 'https://anonymsms.com/netherlands', code: '+31' }
];

function setupFakeNumsCommand(bot) {
    // أمر fakenums
    bot.command(['fakenums', 'ارقام_وهمية', 'أرقام'], async (ctx) => {
        try {
            const countries = COUNTRIES;
            const countriesMap = {};
            countries.forEach(c => { countriesMap[c.key] = c; });
            userSessions.set(ctx.from.id, { allCountries: countriesMap, timestamp: Date.now() });

            const buttons = countries.map((country) => [
                Markup.button.callback(`🔕 ${country.name}`, `view_${country.key}`)
            ]);
            buttons.push([Markup.button.url('📢 قروب الاكواد', GROUP_LINK)]);

            await ctx.reply(`🌍 **الدول المتوفرة:**`, Markup.inlineKeyboard(buttons));
        } catch (e) {
            console.error("خطأ في fakenums:", e);
            await ctx.reply(`❌ حدث خطأ: ${e.message}`);
        }
    });

    // عرض أرقام الدولة
    bot.action(/view_(.+)/, async (ctx) => {
        try {
            const countryKey = ctx.match[1];
            const session = userSessions.get(ctx.from.id);
            if (!session || !session.allCountries || !session.allCountries[countryKey]) {
                return ctx.answerCbQuery("⚠️ انتهت الجلسة، أرسل /fakenums من جديد.");
            }

            const countryData = session.allCountries[countryKey];
            await ctx.answerCbQuery(`⏳ جاري جلب أرقام ${countryData.name}...`);

            const numbers = await fetchNumbersWithLinks(countryData.link, countryData.code);

            if (numbers.length === 0) {
                return ctx.editMessageText(
                    `❌ لا توجد أرقام متاحة حالياً في (${countryData.name}).\n🔄 حاول تحديث الصفحة لاحقاً.`
                );
            }

            userSessions.set(ctx.from.id, {
                ...session,
                numbersData: numbers,
                currentCountry: countryData.name,
                currentCountryKey: countryKey
            });

            let numbersText = numbers.map((item, index) => `${index + 1}. ${item.number}`).join('\n');

            const message =
`╔═━────━❖♛❖━────━═╗
      𓆩تم اختيار الدولة𓆪
الدولة: ${countryData.name}
╚═━────━❖♛❖━────━═╝

📱 **الأرقام المتاحة:**
${numbersText}

👇 اختر رقماً للاستماع (يتم النسخ والاستماع تلقائياً):`;

            // إنشاء أزرار: رقم للاستماع + زر نسخ
            const buttons = [];
            numbers.forEach((item, index) => {
                buttons.push([
                    Markup.button.callback(`📞 ${item.number}`, `listen_${index}`),
                    Markup.button.copyText(`📋 نسخ`, item.number)
                ]);
            });

            buttons.push([
                Markup.button.callback("🔄 تحديث الأرقام", `refresh_${countryKey}`),
                Markup.button.callback("🔙 رجوع", "back")
            ]);
            buttons.push([Markup.button.url('📢 قروب الاكواد', GROUP_LINK)]);

            await ctx.editMessageText(message, Markup.inlineKeyboard(buttons));

        } catch (e) {
            console.error("خطأ في view:", e);
            await ctx.editMessageText(`❌ حدث خطأ: ${e.message}`);
        }
    });

    // بدء الاستماع لرقم مختار (بدون رسالة تأكيد مطولة)
    bot.action(/listen_(\d+)/, async (ctx) => {
        try {
            const index = parseInt(ctx.match[1]);
            const session = userSessions.get(ctx.from.id);
            if (!session || !session.numbersData || !session.numbersData[index]) {
                return ctx.answerCbQuery("⚠️ انتهت الجلسة، أعد اختيار الدولة.");
            }

            const selected = session.numbersData[index];
            const number = selected.number;
            const numberLink = selected.link;

            // بدء الاستماع فوراً
            startListening(bot, ctx.from.id, number, numberLink, session.currentCountry);

            // إرسال رسالة مختصرة جداً (أو تحديث الرسالة السابقة)
            await ctx.answerCbQuery(`🔊 جاري الاستماع للرقم: ${number}`);
            
            // تحديث الرسالة لإظهار أن الاستماع بدأ (بدلاً من رسالة منفصلة)
            await ctx.editMessageText(
                `✅ **جاري الاستماع للرقم:** ${number}\n` +
                `🌍 **الدولة:** ${session.currentCountry}\n` +
                `📨 سيتم إرسال أي كود يصل فوراً.`,
                Markup.inlineKeyboard([
                    [Markup.button.callback("🔙 إيقاف", `stop_${number}`)],
                    [Markup.button.url('📢 قروب الاكواد', GROUP_LINK)]
                ])
            );

        } catch (e) {
            console.error("خطأ في listen:", e);
            await ctx.answerCbQuery("❌ حدث خطأ");
        }
    });

    // إيقاف الاستماع (اختياري)
    bot.action(/stop_(.+)/, async (ctx) => {
        const number = ctx.match[1];
        const userId = ctx.from.id;
        const sessionKey = `${userId}_${number}`;
        if (global.listeners && global.listeners[sessionKey]) {
            clearInterval(global.listeners[sessionKey]);
            delete global.listeners[sessionKey];
            await ctx.answerCbQuery("⏹️ تم إيقاف الاستماع");
            await ctx.editMessageText(`⏹️ تم إيقاف الاستماع للرقم: ${number}`);
        } else {
            await ctx.answerCbQuery("⚠️ لا يوجد استماع نشط لهذا الرقم");
        }
    });

    // تحديث الأرقام (يجلب أرقاماً جديدة من نفس الدولة)
    bot.action(/refresh_(.+)/, async (ctx) => {
        try {
            const countryKey = ctx.match[1];
            const session = userSessions.get(ctx.from.id);
            if (!session || !session.allCountries || !session.allCountries[countryKey]) {
                return ctx.answerCbQuery("⚠️ انتهت الجلسة.");
            }

            const countryData = session.allCountries[countryKey];
            await ctx.answerCbQuery("🔄 جاري تحديث الأرقام...");

            // جلب أرقام جديدة
            const numbers = await fetchNumbersWithLinks(countryData.link, countryData.code);

            if (numbers.length === 0) {
                return ctx.answerCbQuery("⚠️ لا توجد أرقام جديدة حالياً");
            }

            // تحديث الجلسة
            userSessions.set(ctx.from.id, {
                ...session,
                numbersData: numbers,
                currentCountry: countryData.name,
                currentCountryKey: countryKey
            });

            let numbersText = numbers.map((item, index) => `${index + 1}. ${item.number}`).join('\n');

            const message =
`╔═━────━❖♛❖━────━═╗
      𓆩تم تحديث الأرقام𓆪
الدولة: ${countryData.name}
╚═━────━❖♛❖━────━═╝

📱 **الأرقام المتاحة:**
${numbersText}

✅ تم التحديث!
👇 اختر رقماً للاستماع (يتم النسخ والاستماع تلقائياً):`;

            const buttons = [];
            numbers.forEach((item, index) => {
                buttons.push([
                    Markup.button.callback(`📞 ${item.number}`, `listen_${index}`),
                    Markup.button.copyText(`📋 نسخ`, item.number)
                ]);
            });

            buttons.push([
                Markup.button.callback("🔄 تحديث الأرقام", `refresh_${countryKey}`),
                Markup.button.callback("🔙 رجوع", "back")
            ]);
            buttons.push([Markup.button.url('📢 قروب الاكواد', GROUP_LINK)]);

            await ctx.editMessageText(message, Markup.inlineKeyboard(buttons));

        } catch (e) {
            console.error("خطأ في refresh:", e);
            await ctx.answerCbQuery("❌ حدث خطأ في التحديث");
        }
    });

    // الرجوع لقائمة الدول
    bot.action('back', async (ctx) => {
        try {
            const session = userSessions.get(ctx.from.id);
            if (!session || !session.allCountries) {
                return ctx.answerCbQuery("⚠️ انتهت الجلسة، أرسل /fakenums من جديد.");
            }

            const countries = Object.values(session.allCountries);
            const buttons = countries.map((country) => [
                Markup.button.callback(`🔕 ${country.name}`, `view_${country.key}`)
            ]);
            buttons.push([Markup.button.url('📢 قروب الاكواد', GROUP_LINK)]);

            await ctx.editMessageText(`🌍 **الدول المتوفرة:**`, Markup.inlineKeyboard(buttons));
            await ctx.answerCbQuery();
        } catch (e) {
            console.error("خطأ في back:", e);
        }
    });
}

// ============= دوال المساعدة =============

// جلب الأرقام مع تصفيتها حسب رمز الدولة
async function fetchNumbersWithLinks(pageUrl, countryCode) {
    try {
        const response = await axios.get(pageUrl, {
            headers: { 
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            },
            timeout: 10000
        });
        
        const html = response.data;
        if (isProtectionPage(html)) return [];
        
        const $ = cheerio.load(html);
        const result = [];
        const phoneRegex = /^\+?[0-9]{8,15}$/;

        // البحث عن الروابط التي تحوي أرقامًا
        $('a[href]').each((i, el) => {
            if (result.length >= 5) return;
            const href = $(el).attr('href');
            let text = $(el).text().trim();
            if (!text || text.length < 8) return;
            const clean = text.replace(/[\s\-\(\)\.]/g, '');
            if (phoneRegex.test(clean) && clean.startsWith(countryCode)) {
                if (!result.some(item => item.number === clean)) {
                    let numberLink = href;
                    if (numberLink && !numberLink.startsWith('http')) {
                        numberLink = `https://anonymsms.com${numberLink.startsWith('/') ? numberLink : '/' + numberLink}`;
                    }
                    result.push({ number: clean, link: numberLink || pageUrl });
                }
            }
        });

        // إذا لم نجد، نبحث في النص العام
        if (result.length === 0) {
            const bodyText = $('body').text();
            const matches = bodyText.match(/\+?[0-9]{8,15}/g);
            if (matches) {
                for (const match of matches) {
                    if (result.length >= 5) break;
                    const clean = match.replace(/[\s\-\(\)\.]/g, '');
                    if (phoneRegex.test(clean) && clean.startsWith(countryCode)) {
                        if (!result.some(item => item.number === clean)) {
                            result.push({ number: clean, link: pageUrl });
                        }
                    }
                }
            }
        }

        return result;
    } catch (e) {
        console.error('خطأ في جلب الأرقام مع الروابط:', e.message);
        return [];
    }
}

// التحقق من صفحة الحماية
function isProtectionPage(html) {
    const indicators = [
        'Just a moment',
        'Please wait while your request is being verified',
        'Checking your browser',
        'Cloudflare',
        'DDoS protection',
        'verify you are human'
    ];
    const lowerHtml = html.toLowerCase();
    return indicators.some(indicator => lowerHtml.includes(indicator.toLowerCase()));
}

// دالة الاستماع للرقم (بدون رسائل تأكيد إضافية)
function startListening(bot, userId, number, numberLink, countryName) {
    const sessionKey = `${userId}_${number}`;
    let lastMessage = '';
    let attempts = 0;
    const maxAttempts = 60;

    // إيقاف أي مؤقت سابق لنفس الرقم
    if (global.listeners && global.listeners[sessionKey]) {
        clearInterval(global.listeners[sessionKey]);
    }

    const interval = setInterval(async () => {
        attempts++;
        if (attempts > maxAttempts) {
            clearInterval(interval);
            delete global.listeners[sessionKey];
            await bot.telegram.sendMessage(userId, `⏰ انتهت مدة الاستماع للرقم ${number}.`);
            return;
        }

        try {
            const response = await axios.get(numberLink, {
                headers: { 
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                },
                timeout: 10000
            });

            const html = response.data;
            if (isProtectionPage(html)) return;

            const $ = cheerio.load(html);
            let newMessage = '';

            // البحث عن رسائل جديدة
            $('*').each((i, el) => {
                const text = $(el).text().trim();
                if (text.includes(number) && text.length > number.length + 5) {
                    const parts = text.split(number);
                    if (parts.length > 1) {
                        const possibleMsg = parts.slice(1).join(' ').trim();
                        if (possibleMsg.length > 0 && possibleMsg !== lastMessage) {
                            newMessage = possibleMsg;
                            lastMessage = possibleMsg;
                        }
                    }
                }
            });

            if (newMessage) {
                clearInterval(interval);
                delete global.listeners[sessionKey];

                const maskedNumber = number.replace(/(\+\d{3})\d{4}(\d{4})/, '$1⛔$2');
                const formattedMsg = 
`╔═━────━❖♛❖━────━═╗
      𓆩طلب ناجح𓆪
الرقم: ${maskedNumber}
الكود: ${newMessage}
╚═━────━❖♛❖━────━═╝`;

                // إرسال للمستخدم
                await bot.telegram.sendMessage(userId, formattedMsg, { parse_mode: 'Markdown' });

                // إرسال للقروب
                try {
                    await bot.telegram.sendMessage(GROUP_ID, formattedMsg, { parse_mode: 'Markdown' });
                } catch (e) {
                    console.error('فشل الإرسال للقروب:', e.message);
                }
            }

        } catch (e) {
            // تجاهل الأخطاء المؤقتة
        }
    }, 10000); // كل 10 ثوان

    if (!global.listeners) global.listeners = {};
    global.listeners[sessionKey] = interval;
}

module.exports = setupFakeNumsCommand;