const { Markup } = require('telegraf');
const fs = require('fs');
const path = require('path');

const DB_PATH = path.resolve(__dirname, '../قاعده.json');

// دالة لقراءة قاعدة البيانات
function loadDatabase() {
    try {
        if (fs.existsSync(DB_PATH)) {
            const data = fs.readFileSync(DB_PATH, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error("Error reading قاعده.json:", e);
    }
    return [];
}

// دالة لحفظ قاعدة البيانات
function saveDatabase(data) {
    try {
        fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error("Error saving قاعده.json:", e);
    }
}

function setupSpinCommand(bot) {
    // 1. أمر عجلة الحظ
    bot.command(['spin', 'عجله_الحظ', 'عجلة_الحظ'], async (ctx) => {
        try {
            const userId = ctx.from.id;
            let usersList = loadDatabase();
            let userIndex = usersList.findIndex(u => u.id === userId);

            // إذا كان المستخدم غير موجود في القاعدة، نقوم بإضافته برصيد 0 ووقت سابق
            if (userIndex === -1) {
                usersList.push({ id: userId, points: 0, lastSpin: 0 });
                saveDatabase(usersList);
                userIndex = usersList.length - 1;
            }

            const userData = usersList[userIndex];
            const now = Date.now();
            const cooldownTime = 24 * 60 * 60 * 1000; // 24 ساعة بالمللي ثانية
            const lastSpin = userData.lastSpin || 0;

            // التحقق من مرور 24 ساعة
            if (now - lastSpin < cooldownTime) {
                const remainingTime = cooldownTime - (now - lastSpin);
                const hours = Math.floor(remainingTime / (1000 * 60 * 60));
                const minutes = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));

                return ctx.reply(
                    `⏳ **عجلة الحظ مغلقة مؤقتاً!**\n\n` +
                    `لقد قمت بتدوير العجلة مسبقاً. يمكنك اللعب مرة أخرى بعد:\n` +
                    `⏱️ **${hours} ساعة و ${minutes} دقيقة.**`
                );
            }

            // عرض عجلة الحظ مع زر التدوير
            const spinText = 
                `🎡 **أهلاً بك في عجلة الحظ اليومية!**\n\n` +
                `تحتوي العجلة على 3 جوائز قيمة:\n` +
                `💎 **10 نقاط**\n` +
                `💎 **15 نقطة**\n` +
                `💎 **20 نقطة**\n\n` +
                `اضغط على الزر أدناه لتدوير العجلة ومعرفة نصيبك:`;

            await ctx.reply(spinText, Markup.inlineKeyboard([
                [Markup.button.callback('🎡 تدوير العجلة', 'start_spin_wheel')]
            ]));

        } catch (error) {
            console.error("Error in spin command:", error);
            await ctx.reply("❌ حدث خطأ أثناء تشغيل عجلة الحظ.");
        }
    });

    // 2. تفاعل زر التدوير واختيار الجائزة عشوائياً
    bot.action('start_spin_wheel', async (ctx) => {
        try {
            const userId = ctx.from.id;
            let usersList = loadDatabase();
            let userIndex = usersList.findIndex(u => u.id === userId);

            if (userIndex === -1) {
                return ctx.answerCbQuery("❌ يجب عليك تسجيل حسابك أولاً.", { show_alert: true });
            }

            const userData = usersList[userIndex];
            const now = Date.now();
            const cooldownTime = 24 * 60 * 60 * 1000;

            if (now - (userData.lastSpin || 0) < cooldownTime) {
                await ctx.answerCbQuery("❌ لقد قمت بتدوير العجلة اليوم بالفعل!", { show_alert: true });
                return ctx.editMessageText("❌ انتهت صلاحية هذه المحاولة، لقد لعبت مسبقاً اليوم.");
            }

            // رسالة تشويقية أثناء "التدوير"
            await ctx.editMessageText("🎡 **جاري تدوير العجلة واختيار الحظ... حظاً موفقاً!** 🔄");

            // محاكاة حركة التشويق لثانية واحدة
            await new Promise(resolve => setTimeout(resolve, 1500));

            // اختيار جائزة عشوائية من الثلاث (10 أو 15 أو 20)
            const prizes = [10, 15, 20];
            // يمكنك تعديل الاحتمالات لو أردت، هنا اختيار عشوائي متساوی
            const wonPoints = prizes[Math.floor(Math.random() * prizes.length)];

            // تحديث النقاط ووقت آخر استخدام في قاعدة البيانات
            usersList[userIndex].points += wonPoints;
            usersList[userIndex].lastSpin = now;
            saveDatabase(usersList);

            // عرض النتيجة للمستخدم
            const resultText = 
                `🎉 **مبارك لك! لقد استقرت العجلة بنجاح**\n\n` +
                `🎁 الجائزة التي حصلت عليها: **${wonPoints} نقطة**\n` +
                `💰 رصيدك الحالي الجديد: **${usersList[userIndex].points} نقطة**\n\n` +
                `⏳ يمكنك تدوير العجلة مرة أخرى بعد 24 ساعة.`;

            await ctx.editMessageText(resultText);
            await ctx.answerCbQuery(`🎉 مبروك فزت بـ ${wonPoints} نقطة!`, { show_alert: true });

        } catch (error) {
            console.error("Error processing spin action:", error);
            await ctx.answerCbQuery("❌ حدث خطأ أثناء تدوير العجلة.", { show_alert: true });
        }
    });
}

module.exports = setupSpinCommand;