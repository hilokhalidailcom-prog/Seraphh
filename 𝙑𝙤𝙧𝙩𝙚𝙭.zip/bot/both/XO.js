const { Markup } = require('telegraf');
const axios = require('axios');

const activeGames = new Map();
const GROQ_API_KEY = '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';

function setupXoGame(bot) {
    bot.command(['xo', 'لعبة_xo', 'إكس_اوتو'], async (ctx) => {
        try {
            const userId = ctx.from.id;
            
            const isUserX = Math.random() < 0.5;
            const userSymbol = isUserX ? '❌' : '⭕';
            const aiSymbol = isUserX ? '⭕' : '❌';
            const turn = isUserX ? 'user' : 'ai';

            const gameState = {
                board: Array(9).fill('➖'),
                userSymbol,
                aiSymbol,
                turn,
                gameOver: false
            };

            activeGames.set(userId, gameState);

            await ctx.reply(
                `تم بدأ لعبة X/O\nأنت تلعب ضد الـ AI من Groq.\nرمزك: ${userSymbol} | رمز الـ AI: ${aiSymbol}\n\nدور: ${turn === 'user' ? 'دورك (اختر خانة)' : 'دور الـ AI (جاري التفكير...)'}`,
                getBoardKeyboard(gameState.board)
            );

            if (turn === 'ai') {
                await handleAiTurn(ctx, userId);
            }
        } catch (error) {
            console.error("Error in xo command:", error);
        }
    });

    bot.action(/xo_move_(\d+)/, async (ctx) => {
        try {
            const userId = ctx.from.id;
            const game = activeGames.get(userId);

            // إذا انتهت اللعبة (سواء فاز الـ AI أو المستخدم)، أظهر النافذة المنبثقة
            if (game && game.gameOver) {
                return ctx.answerCbQuery("يا خاسر لا تلعب ثاني😹💔", { show_alert: true });
            }

            if (!game) {
                return ctx.answerCbQuery("⚠️ انتهت الجلسة، ابدأ من جديد بـ /xo", { show_alert: true });
            }

            if (game.turn !== 'user') {
                return ctx.answerCbQuery("⚠️ ليس دورك الآن، انتظر دور الـ AI!", { show_alert: true });
            }

            const index = parseInt(ctx.match[1]);
            if (game.board[index] !== '➖') {
                return ctx.answerCbQuery("⚠️ هذه الخانة محجوزة مسبقاً، اختر غيرها.", { show_alert: true });
            }

            // حركة اللاعب
            game.board[index] = game.userSymbol;
            await ctx.answerCbQuery("✅ تم تسجيل حركتك.").catch(() => {});

            // التحقق من فوز اللاعب أو التعادل
            if (checkWin(game.board, game.userSymbol)) {
                game.gameOver = true;
                return await safeEditMessage(
                    ctx,
                    `🎉 مبروك! لقد فزت على الـ AI!\n\n${renderBoardText(game.board)}`,
                    getBoardKeyboard(game.board)
                );
            }

            if (isBoardFull(game.board)) {
                game.gameOver = true;
                return await safeEditMessage(
                    ctx,
                    `🤝 تعادل!\n\n${renderBoardText(game.board)}`,
                    getBoardKeyboard(game.board)
                );
            }

            // تحويل الدور للـ AI
            game.turn = 'ai';
            await safeEditMessage(
                ctx,
                `دور الـ AI (${game.aiSymbol}) يفكر...\n\n${renderBoardText(game.board)}`,
                getBoardKeyboard(game.board)
            );

            await handleAiTurn(ctx, userId);
        } catch (error) {
            console.error("Error in xo_move action:", error);
            await ctx.answerCbQuery("حدث خطأ ما، حاول مجدداً.", { show_alert: true }).catch(() => {});
        }
    });
}

// دالة إدارة دور الـ AI عبر إرسال الحالة للـ Groq API
async function handleAiTurn(ctx, userId) {
    const game = activeGames.get(userId);
    if (!game || game.gameOver) return;

    try {
        const emptyIndices = game.board
            .map((val, idx) => (val === '➖' ? idx : null))
            .filter(val => val !== null);

        if (emptyIndices.length === 0) return;

        const prompt = `You are playing Tic-Tac-Toe. Your symbol is ${game.aiSymbol}. The opponent's symbol is ${game.userSymbol}.
The board indices are from 0 to 8:
0 1 2
3 4 5
6 7 8
Current board state (➖ means empty):
${JSON.stringify(game.board)}
Available empty indices are: ${JSON.stringify(emptyIndices)}.
Choose ONE index from the available indices to place your symbol. Return ONLY the number of the index (0-8) and nothing else.`;

        const response = await axios.post(
            'https://api.groq.com/openai/v1/chat/completions',
            {
                model: 'llama3-8b-8192',
                messages: [{ role: 'user', content: prompt }],
                temperature: 0.5
            },
            {
                headers: {
                    'Authorization': `Bearer ${GROQ_API_KEY}`,
                    'Content-Type': 'application/json'
                },
                timeout: 10000
            }
        );

        const aiText = response.data.choices[0].message.content.trim();
        let chosenIndex = parseInt(aiText.replace(/\D/g, ''));

        if (isNaN(chosenIndex) || !emptyIndices.includes(chosenIndex)) {
            chosenIndex = emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
        }

        game.board[chosenIndex] = game.aiSymbol;

        // التحقق من فوز الـ AI أو التعادل
        if (checkWin(game.board, game.aiSymbol)) {
            game.gameOver = true;
            return await safeEditMessage(
                ctx,
                `🤖 حظاً أوفر! فاز الـ AI عليك.\n\n${renderBoardText(game.board)}`,
                getBoardKeyboard(game.board)
            );
        }

        if (isBoardFull(game.board)) {
            game.gameOver = true;
            return await safeEditMessage(
                ctx,
                `🤝 تعادل!\n\n${renderBoardText(game.board)}`,
                getBoardKeyboard(game.board)
            );
        }

        // إرجاع الدور للاعب
        game.turn = 'user';
        await safeEditMessage(
            ctx,
            `دورك (${game.userSymbol}) - اختر خانة:\n\n${renderBoardText(game.board)}`,
            getBoardKeyboard(game.board)
        );

    } catch (e) {
        console.error("Groq API Error or AI Turn Error:", e.message);
        
        const emptyIndices = game.board
            .map((val, idx) => (val === '➖' ? idx : null))
            .filter(val => val !== null);
            
        if (emptyIndices.length > 0) {
            const fallbackIndex = emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
            game.board[fallbackIndex] = game.aiSymbol;

            if (checkWin(game.board, game.aiSymbol)) {
                game.gameOver = true;
                await safeEditMessage(
                    ctx,
                    `🤖 حظاً أوفر! فاز الـ AI عليك.\n\n${renderBoardText(game.board)}`,
                    getBoardKeyboard(game.board)
                );
                return;
            }

            if (isBoardFull(game.board)) {
                game.gameOver = true;
                await safeEditMessage(
                    ctx,
                    `🤝 تعادل!\n\n${renderBoardText(game.board)}`,
                    getBoardKeyboard(game.board)
                );
                return;
            }

            game.turn = 'user';
            await safeEditMessage(
                ctx,
                `دورك (${game.userSymbol}) - اختر خانة:\n\n${renderBoardText(game.board)}`,
                getBoardKeyboard(game.board)
            );
        }
    }
}

// بناء الأزرار التفاعلية للوحة (نشطة دائماً)
function getBoardKeyboard(board) {
    const buttons = [];
    for (let i = 0; i < 9; i += 3) {
        buttons.push([
            Markup.button.callback(board[i], `xo_move_${i}`),
            Markup.button.callback(board[i + 1], `xo_move_${i + 1}`),
            Markup.button.callback(board[i + 2], `xo_move_${i + 2}`)
        ]);
    }
    return Markup.inlineKeyboard(buttons);
}

// دالة مساعدة لتعديل الرسائل بأمان تام
async function safeEditMessage(ctx, text, replyMarkup) {
    try {
        await ctx.editMessageText(text, replyMarkup);
    } catch (error) {
        if (!error.message.includes('message is not modified')) {
            console.error("Safe edit message error:", error.message);
        }
    }
}

function renderBoardText(board) {
    return `${board[0]} | ${board[1]} | ${board[2]}\n` +
           `-----------\n` +
           `${board[3]} | ${board[4]} | ${board[5]}\n` +
           `-----------\n` +
           `${board[6]} | ${board[7]} | ${board[8]}`;
}

function checkWin(b, symbol) {
    const winCombos = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8],
        [0, 4, 8], [2, 4, 6]
    ];
    return winCombos.some(combo => combo.every(idx => b[idx] === symbol));
}

function isBoardFull(b) {
    return b.every(cell => cell !== '➖');
}

module.exports = setupXoGame;