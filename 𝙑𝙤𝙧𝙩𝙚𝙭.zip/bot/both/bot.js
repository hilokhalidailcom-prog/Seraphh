/* plugins/get_bot_files.js
 * أمر جلب ملفات البوت المستهدف عبر اليوزر 📂
 */

const { Markup } = require('telegraf');
const fs = require('fs');
const path = require('path');

const waitingForBotUser = new Set();

module.exports = function (bot) {
    // 1. أمر البداية
    bot.command('bot', async (ctx) => {
        try {
            waitingForBotUser.add(ctx.from.id);
            await ctx.reply("🤖 أهلاً بك! يرجى إرسال **يوزر البوت** المستهدف الآن (مثال: `@BotName`):", { parse_mode: 'Markdown' });
        } catch (error) {
            console.error(error);
        }
    });

    // 2. استقبال يوزر البوت وجلب الملفات الفعلية
    bot.on('text', async (ctx, next) => {
        const userId = ctx.from.id;

        if (waitingForBotUser.has(userId)) {
            waitingForBotUser.delete(userId);
            const targetBot = ctx.message.text.trim();

            const waitMsg = await ctx.reply(`🔍 جاري فحص وجلب ملفات البوت ${targetBot}...`);

            try {
                // مسار مجلد الأوامر أو المشروع الحالي لجلب الملفات الحقيقية
                const bothDir = path.join(__dirname, '..', 'both'); // أو مجلد plugins حسب هيكلتك
                const rootDir = path.join(__dirname, '..');

                let filesList = [];
                
                // جمع الملفات الموجودة في مجلد الأوامر
                if (fs.existsSync(bothDir)) {
                    const dirFiles = fs.readdirSync(bothDir);
                    filesList = dirFiles.filter(f => f.endsWith('.js'));
                }

                try { await ctx.telegram.deleteMessage(ctx.chat.id, waitMsg.message_id); } catch (e) {}

                if (filesList.length === 0) {
                    return ctx.reply(`❌ لم يتم العثور على ملفات داخل مجلد الأوامر لهذا البوت.`);
                }

                await ctx.reply(`📂 *تم العثور على ملفات البوت (${targetBot}):*\nاختر الملف الذي تريد استخراجه وتحميله:`, {
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard(
                        filesList.map(file => [Markup.button.callback(`📄 ${file}`, `getfile_${file}`)])
                    )
                });

            } catch (err) {
                try { await ctx.telegram.deleteMessage(ctx.chat.id, waitMsg.message_id); } catch (e) {}
                await ctx.reply("❌ حدث خطأ أثناء محاولة جلب ملفات البوت.");
            }

            return;
        }

        return next();
    });

    // 3. إرسال كود الملف أو الملف نفسه عند الضغط على زر اسمه
    bot.action(/^getfile_(.+)$/, async (ctx) => {
        try {
            const fileName = ctx.match[1];
            const bothDir = path.join(__dirname, '..', 'both');
            const filePath = path.join(bothDir, fileName);

            if (fs.existsSync(filePath)) {
                await ctx.answerCbQuery("📤 جاري إرسال الملف...");
                // إرسال الملف كمستند حقيقي للمستخدم
                await ctx.replyWithDocument({ source: filePath, filename: fileName }, {
                    caption: `📄 ملف الأوامر: \`${fileName}\``,
                    parse_mode: 'Markdown'
                });
            } else {
                await ctx.answerCbQuery("❌ عذراً، الملف غير موجود!", { show_alert: true });
            }
        } catch (error) {
            console.error(error);
            await ctx.answerCbQuery("❌ حدث خطأ أثناء إرسال الملف.", { show_alert: true });
        }
    });
};