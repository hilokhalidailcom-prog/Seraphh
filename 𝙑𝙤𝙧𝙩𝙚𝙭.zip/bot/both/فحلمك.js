// دن تم التطوير بواسطه داكس المظ🐦مطور بوت سيراف
// لا تحذف السطرين دول بل حب😭🗿

const { Markup } = require('telegraf');

const idSessions = new Map();

function setupGetChannelIdCommand(bot) {
    bot.command('id', async (ctx) => {
        try {
            const userId = ctx.from.id;
            idSessions.set(userId, { step: 'waiting_for_link' });

            await ctx.reply(
                "🆔 *نظام استخراج آيدي ومعرفات القنوات والقروبات*\n\n🔗 يرجى إرسال رابط القناة، رابط القروب، رابط الدعوة (Invite Link)، أو المعرف (Username) (مثل: `https://t.me/...` أو `@username`):",
                {
                    parse_mode: 'Markdown',
                    ...Markup.forceReply()
                }
            );
        } catch (error) {
            console.error("Error in /id command:", error);
        }
    });

    bot.on('text', async (ctx, next) => {
        try {
            const userId = ctx.from.id;
            const session = idSessions.get(userId);

            if (!session) {
                return next();
            }

            let input = ctx.message.text.trim();
            idSessions.delete(userId);

            await ctx.reply('⏳ جاري فحص الرابط وجلب الآيدي والمعلومات...');

            let target = input;

            // معالجة روابط تليجرام بأنواعها (العامة والخاصة/روابط الدعوة)
            if (input.includes('t.me/')) {
                const parts = input.split('t.me/')[1].split('?')[0];
                if (parts.startsWith('+') || parts.startsWith('joinchat/')) {
                    // إذا كان رابط دعوة خاص للقروبات
                    target = input;
                } else {
                    target = parts.split('/')[0];
                }
            }

            // تعديل شكل المعرف ليكون بالشكل الصحيح للبحث
            if (target.startsWith('+') || target.includes('t.me/+') || target.includes('t.me/joinchat/')) {
                // روابط الدعوة الخاصة تترك كما هي لأن تيليجرام يتعامل معها مباشرة عبر getChat
            } else if (target.startsWith('@')) {
                target = target;
            } else if (!target.startsWith('-') && !target.startsWith('https://')) {
                target = `@${target}`;
            }

            const chatInfo = await bot.telegram.getChat(target);

            const chatTitle = chatInfo.title || 'غير معروف';
            const chatId = chatInfo.id;
            const chatUsername = chatInfo.username ? `@${chatInfo.username}` : 'لا يوجد (مجموعة/قروب خاص)';
            const chatType = chatInfo.type;
            const inviteLink = chatInfo.invite_link || 'غير متوفر (أو البوت ليس مشرفاً للصلاحية)';

            let typeName = 'دردشة';
            if (chatType === 'channel') typeName = 'قناة';
            else if (chatType === 'supergroup') typeName = 'مجموعة خارقة / قروب';
            else if (chatType === 'group') typeName = 'مجموعة عادية / قروب';

            const resultMessage = 
`✅ *تم جلب معلومات الدردشة بنجاح!*

📌 *الاسم:* ${chatTitle}
🔗 *المعرف (Username):* ${chatUsername}
🆔 *الآيدي (ID):* \`${chatId}\`
📂 *النوع:* ${chatType} (${typeName})
🌐 *رابط الانضمام:* ${inviteLink}`;

            await ctx.reply(resultMessage, { parse_mode: 'Markdown' });

        } catch (error) {
            console.error("Error fetching chat ID for group/channel:", error);
            idSessions.delete(ctx.from.id);
            
            await ctx.reply(
                "❌ *فشل في جلب الآيدي والمعلومات!*\n\nالأسباب المحتملة:\n1. الرابط أو المعرف خطأ.\n2. إذا كان القروب أو القناة الخاصة برابط دعوة، يجب أن يكون البوت عضواً أو مشرفاً داخلها ليتمكن من جلب بياناته.\n3. تأكد من صحة الرابط المرسل."
            );
        }
    });
}

module.exports = setupGetChannelIdCommand;