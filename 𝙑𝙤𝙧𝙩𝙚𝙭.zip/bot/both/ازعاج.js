const { Markup } = require('telegraf');
const fs = require('fs');
const path = require('path');

const DB_PATH = path.resolve(__dirname, '../قاعده.json');

// دالة لقراءة قاعدة البيانات
function loadDatabase() {
    try {
        if (fs.existsSync(DB_PATH)) {
            const data = fs.readFileSync(DB_PATH, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error("Error reading قاعده.json:", e);
    }
    return [];
}

// دالة لحفظ قاعدة البيانات
function saveDatabase(data) {
    try {
        fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error("Error saving قاعده.json:", e);
    }
}

function setupPairingCommand(bot) {
    const waitingForNumber = new Set();

    // أمر ربط للكل مع فحص النقاط مسبقاً
    bot.command('link', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const usersList = loadDatabase();

            // 1. التحقق من وجود المستخدم وامتلاكه لـ 10 نقاط على الأقل
            const userIndex = usersList.findIndex(user => user.id === userId);
            if (userIndex === -1 || usersList[userIndex].points < 10) {
                return ctx.reply("ليس معك نقاط");
            }

            waitingForNumber.add(userId);
            await ctx.reply('📱 يرجى إرسال الرقم الآن لعمل طلبات الربط:', Markup.forceReply());
        } catch (error) {
            console.error("Error in /link command:", error);
        }
    });

    // استقبال الرسائل النصية (الرقم)
    bot.on('text', async (ctx, next) => {
        const userId = ctx.from.id;

        if (waitingForNumber.has(userId)) {
            waitingForNumber.delete(userId);
            const phoneNumber = ctx.message.text.trim();

            try {
                // تحقق إضافي سريع من النقاط قبل بدء التنفيذ
                let usersList = loadDatabase();
                let userIndex = usersList.findIndex(user => user.id === userId);
                if (userIndex === -1 || usersList[userIndex].points < 10) {
                    return ctx.reply("ليس معك نقاط");
                }

                // 2. إرسال رسالة تأكيد الدفع فوراً قبل بدء التنفيذ ولا يوجد تراجع
                await ctx.reply("تم تاكيد الدفع لايوجد تراجع");

                await ctx.reply(`⏳ جاري إرسال 15 طلبات كود ربط للرقم: ${phoneNumber}...`);

                // حلقة تكرار الـ 15 محاولة
                for (let i = 1; i <= 15; i++) {
                    // يمكنك هنا استبدال هذا السطر بالكود الفعلي أو الطلب الحقيقي للربط
                    await ctx.reply(`🔄 المحاولة رقم (${i}) للرقم: ${phoneNumber} - تم إرسال طلب الكود بنجاح.`);
                    
                    // تأخير بسيط بين كل طلب وآخر (1 ثانية)
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }

                // 3. تمت العملية بنجاح كامل، الآن نقوم بخصم 10 نقاط وحفظ الملف في قاعده.json
                usersList[userIndex].points -= 10;
                saveDatabase(usersList);

                await ctx.reply(`✅ تمت عملية إرسال الـ 15 طلبات بنجاح وتم خصم 10 نقاط. (رصيدك الحالي: ${usersList[userIndex].points})`);

            } catch (error) {
                console.error("Error during pairing process:", error);
                // لو حصلت أي مشكلة أثناء الإرسال، لن يتم خصم النقاط نهائياً
                await ctx.reply(`❌ حدثت مشكلة أثناء تنفيذ الطلب، ولم يتم خصم أي نقاط منك.`);
            }
            return;
        }

        return next();
    });
}

module.exports = setupPairingCommand;