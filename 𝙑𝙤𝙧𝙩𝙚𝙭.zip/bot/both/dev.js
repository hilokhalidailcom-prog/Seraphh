const ADMIN_ID = 8112442788; // استبدل الرقم بآيدي المطور الخاص بك

module.exports = function(bot) {
    bot.command('dev', (ctx) => {
        const userId = ctx.from.id;

        if (userId === ADMIN_ID) {
            ctx.reply('مطوري احبك ❤️👨‍💻');
        } else {
            ctx.reply('مين انت؟ 🤨');
        }
    });
};