const { Markup } = require('telegraf');

function setupAddBotCommand(bot) {
    // أمر /add أو /اضف لإرسال زر إضافة البوت للقروب
    bot.command(['add', 'اضف', 'إضافة'], async (ctx) => {
        const botUsername = ctx.botInfo.username;
        const addLink = `https://t.me/${botUsername}?startgroup=true`;

        await ctx.reply(
            "اضغط على الزر أدناه لاختيار مجموعتك وإضافة البوت إليها:",
            Markup.inlineKeyboard([
                [Markup.button.url('ضيفني الى مجموعتك', addLink)]
            ])
        );
    });

    // رصد دخول البوت إلى أي قروب أو قناة جديدة
    bot.on('my_chat_member', async (ctx) => {
        const newStatus = ctx.myChatMember.new_chat_member.status;
        
        // التحقق من أن البوت تم إضافته وأصبح عضواً أو مشرفاً
        if (['member', 'administrator'].includes(newStatus)) {
            const chatType = ctx.chat.type;
            
            // التأكد من أن الحدث تم في مجموعة أو سوبر غروب
            if (chatType === 'group' || chatType === 'supergroup') {
                try {
                    await ctx.reply("تم ضفتني خلاص");
                } catch (e) {
                    console.error("خطأ أثناء إرسال رسالة الترحيب في القروب:", e);
                }
            }
        }
    });
}

module.exports = setupAddBotCommand;