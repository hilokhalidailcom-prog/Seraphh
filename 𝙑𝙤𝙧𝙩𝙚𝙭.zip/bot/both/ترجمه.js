// تم التطوير بواسطه داكس المظ🐦مطور بوت سيراف
// لا تحذف السطرين دول بل حب😭🗿

const fs = require('fs');
const path = require('path');
const { Markup } = require('telegraf');

const DB_PATH = path.resolve(__dirname, '../قاعده.json');

// قراءة قاعدة البيانات
function loadDatabase() {
    try {
        if (!fs.existsSync(DB_PATH)) {
            return [];
        }

        const data = fs.readFileSync(DB_PATH, 'utf8');

        if (!data.trim()) {
            return [];
        }

        const jsonData = JSON.parse(data);

        return Array.isArray(jsonData)
            ? jsonData
            : [];
    } catch (error) {
        console.error(
            'Error reading قاعده.json:',
            error
        );

        return [];
    }
}

// حفظ قاعدة البيانات
function saveDatabase(data) {
    try {
        fs.writeFileSync(
            DB_PATH,
            JSON.stringify(data, null, 2),
            'utf8'
        );
    } catch (error) {
        console.error(
            'Error saving قاعده.json:',
            error
        );
    }
}

// الحصول على المستخدم
function getUser(userId) {
    const users = loadDatabase();

    return users.find(
        user => user.id === userId
    );
}

// الحصول على لغة المستخدم
function getUserLanguage(userId) {
    const user = getUser(userId);

    if (!user) {
        return null;
    }

    return user['the language'] || 'ar';
}

// تغيير لغة المستخدم
function setUserLanguage(userId, language) {

    const users = loadDatabase();

    const userIndex = users.findIndex(
        user => user.id === userId
    );

    if (userIndex === -1) {
        return false;
    }

    users[userIndex]['the language'] = language;

    saveDatabase(users);

    return true;
}


function setupLanguageCommand(bot) {

    // الأمر /language
    bot.command(
        ['language', 'lang', 'لغة', 'لغتي'],
        async (ctx) => {

            try {

                const userId = ctx.from.id;

                const user = getUser(userId);

                // المستخدم غير مسجل
                if (!user) {

                    return ctx.reply(
                        '❌ لا يمكنك استخدام هذا البوت\n\n' +
                        'يجب عليك التسجيل في البوت أولاً.\n' +
                        'اكتب "ناهه" ليتم تسجيلك.'
                    );
                }

                // المستخدم مسجل
                const language =
                    user['the language'];

                // إذا كانت اللغة إنجليزية
                if (language === 'en') {

                    return ctx.reply(
                        'Your current language is English.\n\n' +
                        'Choose your language / اختر لغتك',
                        Markup.inlineKeyboard([
                            [
                                Markup.button.callback(
                                    '🇸🇦 عربي',
                                    'language_ar'
                                ),
                                Markup.button.callback(
                                    '🇺🇸 English',
                                    'language_en'
                                )
                            ]
                        ])
                    );
                }

                // العربية هي الافتراضية
                return ctx.reply(
                    'اختر لغتك / Choose your language',
                    Markup.inlineKeyboard([
                        [
                            Markup.button.callback(
                                '🇸🇦 عربي',
                                'language_ar'
                            ),
                            Markup.button.callback(
                                '🇺🇸 English',
                                'language_en'
                            )
                        ]
                    ])
                );

            } catch (error) {

                console.error(
                    'Error in language command:',
                    error
                );

                await ctx.reply(
                    '❌ حدث خطأ.'
                );
            }
        }
    );


    // اختيار العربية
    bot.action(
        'language_ar',
        async (ctx) => {

            try {

                await ctx.answerCbQuery();

                const userId = ctx.from.id;

                const user = getUser(userId);

                if (!user) {
                    return ctx.editMessageText(
                        '❌ لا يمكنك استخدام هذا البوت\n\n' +
                        'يجب عليك التسجيل في البوت أولاً.\n' +
                        'اكتب "ناهه" ليتم تسجيلك.'
                    );
                }

                setUserLanguage(
                    userId,
                    'ar'
                );

                await ctx.editMessageText(
                    '🇸🇦 تم تغيير لغة البوت إلى العربية بنجاح.'
                );

            } catch (error) {

                console.error(
                    'Error changing language to Arabic:',
                    error
                );
            }
        }
    );


    // اختيار الإنجليزية
    bot.action(
        'language_en',
        async (ctx) => {

            try {

                await ctx.answerCbQuery();

                const userId = ctx.from.id;

                const user = getUser(userId);

                if (!user) {
                    return ctx.editMessageText(
                        '❌ You cannot use this bot.\n\n' +
                        'You must register first.\n' +
                        'Type "ناهه" to register.'
                    );
                }

                setUserLanguage(
                    userId,
                    'en'
                );

                await ctx.editMessageText(
                    '🇺🇸 The bot language has been changed to English successfully.'
                );

            } catch (error) {

                console.error(
                    'Error changing language to English:',
                    error
                );
            }
        }
    );
}


// دالة ترجمة مركزية
function t(userId, ar, en) {

    const language =
        getUserLanguage(userId);

    if (language === 'en') {
        return en;
    }

    return ar;
}

module.exports = {
    setupLanguageCommand,
    getUserLanguage,
    getUser,
    t
};