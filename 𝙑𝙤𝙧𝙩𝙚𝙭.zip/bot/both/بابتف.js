const path = require('path');
const fs = require('fs');

module.exports = (bot) => {
    bot.command('package', async (ctx) => {
        // المسار يفترض أن الملف موجود في المجلد الرئيسي (مستوى واحد فوق المجلد الحالي)
        const packagePath = path.join(__dirname, '..', 'package.json');

        if (fs.existsSync(packagePath)) {
            try {
                await ctx.replyWithDocument(
                    { source: packagePath, filename: 'package.json' },
                    { caption: '📦 **تم العثور على ملف package.json بنجاح:**' }
                );
            } catch (err) {
                console.error(err);
                ctx.reply("❌ حدث خطأ أثناء إرسال الملف.");
            }
        } else {
            ctx.reply("⚠️ لم يتم العثور على ملف `package.json` في المجلد الرئيسي.");
        }
    });
};