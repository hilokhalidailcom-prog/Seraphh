const axios = require('axios');

function setupGithubDownloadCommand(bot) {
    // أمر جلب الملف المضغوط من المستودع متاح للكل
    bot.command('getzip', async (ctx) => {
        await ctx.reply('⏳ جاري تحميل الملف المضغوط من المستودع...');

        try {
            // رابط تحميل ملف الـ ZIP الرئيسي للمستودع من فرع main
            const zipUrl = 'https://github.com/ibrahimsamir5090-ui/-/archive/refs/heads/main.zip';

            // جلب الملف على شكل Buffer
            const response = await axios.get(zipUrl, { responseType: 'arraybuffer' });
            const buffer = Buffer.from(response.data);

            // إرسال الملف المضغوط عبر تيليجرام
            await ctx.replyWithDocument({
                source: buffer,
                filename: 'repository.zip'
            });
        } catch (error) {
            // في حال كان الفرع اسمه master بدل main
            try {
                const altZipUrl = 'https://github.com/ibrahimsamir5090-ui/-/archive/refs/heads/master.zip';
                const altResponse = await axios.get(altZipUrl, { responseType: 'arraybuffer' });
                const altBuffer = Buffer.from(altResponse.data);

                await ctx.replyWithDocument({
                    source: altBuffer,
                    filename: 'repository.zip'
                });
            } catch (err) {
                await ctx.reply('❌ حدث خطأ أثناء محاولة تحميل الملف المضغوط من جيت هب.');
            }
        }
    });
}

module.exports = setupGithubDownloadCommand;