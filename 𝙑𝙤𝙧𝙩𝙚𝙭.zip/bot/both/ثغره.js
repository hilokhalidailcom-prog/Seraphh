const { Markup } = require('telegraf');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const Groq = require('groq-sdk');

const GROQ_API_KEY = "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";
const TARGET_CHANNEL_ID = "-1004457851009";
const DB_PATH = path.resolve(__dirname, '../قاعده.json');

const groq = new Groq({ apiKey: GROQ_API_KEY });
const activeSrySessions = new Map();

// دالة لقراءة قاعدة البيانات
function loadDatabase() {
    try {
        if (fs.existsSync(DB_PATH)) {
            const data = fs.readFileSync(DB_PATH, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error("Error reading قاعده.json:", e);
    }
    return [];
}

// دالة لحفظ قاعدة البيانات
function saveDatabase(data) {
    try {
        fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error("Error saving قاعده.json:", e);
    }
}

// دالة لتنظيف الرموز غير المدعومة في تيليجرام HTML لمنع أخطاء الـ parse
function escapeHtml(text) {
    return text
        .replace(/<br\s*[\/]?>/gi, '\n') // تحويل <br> إلى أسطر جديدة عادية
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

// دالة لتقسيم الرسائل الطويلة إلى أجزاء لتجنب حدود تيليجرام (4096 حرف)
async function sendLongMessage(ctx, text, options = {}) {
    const MAX_LENGTH = 4000;
    if (text.length <= MAX_LENGTH) {
        return await ctx.reply(text, options);
    }

    let parts = [];
    while (text.length > 0) {
        let part = text.substring(0, MAX_LENGTH);
        let lastNewline = part.lastIndexOf('\n');
        if (lastNewline > 3000) {
            part = text.substring(0, lastNewline);
            text = text.substring(lastNewline + 1);
        } else {
            text = text.substring(MAX_LENGTH);
        }
        parts.push(part);
    }

    for (let i = 0; i < parts.length; i++) {
        await ctx.reply(parts[i], options);
    }
}

// دالة بسيطة للتحقق من صحة الرابط
function isValidUrl(string) {
    try {
        let url = new URL(string);
        return url.protocol === "http:" || url.protocol === "https:";
    } catch (_) {
        try {
            let url = new URL(`https://${string}`);
            return url.hostname.includes('.');
        } catch (e) {
            return false;
        }
    }
}

function setupSryCommand(bot) {
    // 1. أمر /sry للتحقق من النقاط وطلب رابط الموقع من المستخدم
    bot.command('sry', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const usersList = loadDatabase();

            // فحص امتلاك 10 نقاط على الأقل
            const userIndex = usersList.findIndex(user => user.id === userId);
            if (userIndex === -1 || usersList[userIndex].points < 10) {
                return ctx.reply("ليس معك نقاط");
            }

            activeSrySessions.set(userId, { step: 'waiting_for_url' });

            await ctx.reply(
                "🌐 **أهلاً بك في نظام فحص الثغرات الأمني.**\nالرجاء إرسال رابط الموقع المراد فحص ثغراته الآن (مثال: `example.com`):",
                Markup.forceReply()
            );
        } catch (error) {
            console.error("Error in /sry command:", error);
        }
    });

    // 2. استقبال الرابط وتحليله للبحث عن الثغرات
    bot.on('text', async (ctx, next) => {
        try {
            const userId = ctx.from.id;
            const session = activeSrySessions.get(userId);

            if (!session) {
                return next();
            }

            // تحقق إضافي من النقاط قبل بدء التنفيذ
            let usersList = loadDatabase();
            let userIndex = usersList.findIndex(user => user.id === userId);
            if (userIndex === -1 || usersList[userIndex].points < 10) {
                activeSrySessions.delete(userId);
                return ctx.reply("ليس معك نقاط");
            }

            let targetUrl = ctx.message.text.trim();

            if (!isValidUrl(targetUrl)) {
                activeSrySessions.delete(userId);
                return ctx.reply("❌ **خطأ:** النص الذي أرسلته لا يمثل رابط موقع صالحاً.\nالرجاء استخدام الأمر من جديد `/sry` وإرسال رابط صحيح (مثال: `https://google.com`).");
            }

            if (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://')) {
                targetUrl = 'https://' + targetUrl;
            }

            activeSrySessions.delete(userId);

            // إرسال رسالة تأكيد الدفع فوراً وعدم التراجع
            await ctx.reply("تم تاكيد الدفع لايوجد تراجع");

            await ctx.reply(`⏳ جاري فحص الموقع وتحليل الثغرات الأمنية المحتملة للرابط: ${targetUrl} ...`);

            const prompt = `You are an expert cybersecurity penetration tester. Analyze this target URL/domain structure: ${targetUrl}.
Provide a realistic security assessment in Arabic language. If the domain appears generic, non-existent, or invalid, note potential architectural risks based on standard web practices. Include:
1. الثغرات المحتملة (Potential Vulnerabilities)
2. مستوى الخطورة (Severity Level)
3. كيفية الفحص أو المعالجة (Remediation / Mitigation)
ملاحظة هامة: لا تستخدم أي وسوم HTML نهائياً مثل <br> أو ما شابه في ردك.`;

            const completion = await groq.chat.completions.create({
                model: 'openai/gpt-oss-120b',
                messages: [{ role: 'user', content: prompt }],
                temperature: 0.3,
                max_tokens: 4000
            });

            const rawReport = completion.choices[0]?.message?.content || "تعذر إتمام الفحص أو العثور على بيانات.";
            
            // تنظيف التقرير لمنع أي أخطاء في وسوم تيليجرام
            const vulnerabilityReport = escapeHtml(rawReport);

            const formattedOutput = 
`🛡️ <b>تقرير فحص الثغرات الأمنية للموقع:</b>\n` +
`🔗 <b>الرابط:</b> ${targetUrl}\n\n` +
`----------------------------------------\n` +
vulnerabilityReport +
`\n----------------------------------------`;

            // إرسال التقرير (مع دعم تقسيم الرسائل الطويلة تلقائياً)
            await sendLongMessage(ctx, formattedOutput, { parse_mode: 'HTML' });

            // ======== تمت العملية بنجاح كامل، يتم خصم 10 نقاط وحفظها ========
            usersList[userIndex].points -= 10;
            saveDatabase(usersList);

            // تحديد بيانات المستخدم للقناة بشكل صحيح
            const username = ctx.from.username ? `@${ctx.from.username}` : (ctx.from.first_name || "مستخدم");
            const currentTime = new Date().toLocaleString('ar-SA', { timeZone: 'Asia/Riyadh' });

            const channelNotification = `༺━━━━━━━━━━━━༻\n` +
                                        `تم اكمال طلب بنجاح√\n` +
                                        `الطلب: اكتشاف ثغره في موقع\n` +
                                        `الوصف: فحص الثغرات للرابط: ${targetUrl}\n` +
                                        `المستخدم: ${username}\n` +
                                        `الوقت: ${currentTime}\n` +
                                        `نشكركم لاستخدام بوت سيراف 🥀\n` +
                                        `༺━━━━━━━━━━━━༻`;

            await bot.telegram.sendMessage(TARGET_CHANNEL_ID, channelNotification, { parse_mode: 'HTML' });

        } catch (error) {
            console.error("Error analyzing website vulnerabilities:", error.message);
            activeSrySessions.delete(ctx.from.id);
            // لو حدثت أي مشكلة، لن يتم خصم أي نقاط من المستخدم أبداً
            await ctx.reply(`❌ حدث خطأ أثناء الاتصال بنظام الفحص الأمني، ولم يتم خصم أي نقاط منك:\n${error.message}`);
        }
    });
}

module.exports = setupSryCommand;