// ضع آيدي المطور الخاص بك هنا (يمكنك معرفته من بوتات مثل @userinfobot)
const ADMIN_ID = 123456789; 

function setupAdminCommands(bot) {
    // وسيط (Middleware) للتحقق مما إذا كان المستخدم هو المطور
    const adminOnly = (ctx, next) => {
        const userId = ctx.from.id;
        if (userId === ADMIN_ID) {
            return next();
        } else {
            return ctx.reply('عذراً، هذا الأمر مخصص للمطور فقط ⚠️');
        }
    };

    // لوحة تحكم المطور
    bot.command('admin', adminOnly, (ctx) => {
        ctx.reply('أهلاً بك يا مطور البوت 👨‍💻\nلوحة التحكم جاهزة.');
    });

    // أمر خاص بالمطور لتخريب/إيقاف شيء معين أو إدارة البوت
    bot.command('broadcast', adminOnly, (ctx) => {
        ctx.reply('تم تنفيذ أمر المطور بنجاح.');
    });
}

module.exports = setupAdminCommands;
