const { Markup } = require('telegraf');
const Groq = require('groq-sdk');
const fs = require('fs');
const path = require('path');

const GROQ_API_KEY = "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";
const TARGET_CHANNEL_ID = "-1004457851009";
const DB_PATH = path.resolve(__dirname, '../قاعده.json');

const groq = new Groq({ apiKey: GROQ_API_KEY });
const activeBruteSessions = new Map();

// دالة لقراءة قاعدة البيانات
function loadDatabase() {
    try {
        if (fs.existsSync(DB_PATH)) {
            const data = fs.readFileSync(DB_PATH, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error("Error reading قاعده.json:", e);
    }
    return [];
}

// دالة لحفظ قاعدة البيانات
function saveDatabase(data) {
    try {
        fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error("Error saving قاعده.json:", e);
    }
}

function setupBruteCommand(bot) {
    // 1. أمر /brute مع فحص امتلاك 11 نقطة على الأقل
    bot.command('brute', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const usersList = loadDatabase();

            const userIndex = usersList.findIndex(user => user.id === userId);
            if (userIndex === -1 || usersList[userIndex].points < 11) {
                return ctx.reply("ليس معك نقاط");
            }

            activeBruteSessions.set(userId, { step: 'waiting_for_target' });

            await ctx.reply(
                "🔐 **أهلاً بك في نظام توليد قوائم كلمات المرور الكبيرة (أكثر من 1000 كلمة).**\nالرجاء إرسال معلومات الشخص المستهدف (الاسم، البريد، رقم الهاتف، أو تفاصيل عنه):",
                Markup.forceReply()
            );
        } catch (error) {
            console.error("Error in /brute command:", error);
        }
    });

    // 2. استقبال الهدف وتوليد الملف الضخم
    bot.on('text', async (ctx, next) => {
        try {
            const userId = ctx.from.id;
            const session = activeBruteSessions.get(userId);

            if (!session) {
                return next();
            }

            // تحقق إضافي من النقاط قبل بدء العمليات الثقيلة
            let usersList = loadDatabase();
            let userIndex = usersList.findIndex(user => user.id === userId);
            if (userIndex === -1 || usersList[userIndex].points < 11) {
                activeBruteSessions.delete(userId);
                return ctx.reply("ليس معك نقاط");
            }

            const targetInfo = ctx.message.text.trim();
            activeBruteSessions.delete(userId);

            // 3. إرسال رسالة تأكيد الدفع فوراً وعدم التراجع
            await ctx.reply("تم تاكيد الدفع لايوجد تراجع");

            await ctx.reply(`⏳ جاري توليد قائمة ضخمة تضم أكثر من 1000 كلمة مرور (ضعيفة وقوية) بناءً على الهدف (${targetInfo})، قد يستغرق ذلك بضع ثوانٍ...`);

            const prompt = `You are an advanced cybersecurity penetration testing assistant. Based on this target information: "${targetInfo}", generate a massive and comprehensive wordlist containing OVER 1000 passwords. 
Structure the response into two distinct sections:
1. Weak Passwords (كلمات المرور الضعيفة والشائعة والتواريخ والأرقام المتسلسلة والمشتقة من اسم الهدف - املأ هذا القسم بعدد كبير جداً من الاختلافات).
2. Strong Passwords (كلمات المرور القوية والمعقدة والمحتملة التي تدمج الرموز والحروف الكبيرة والصغيرة والأنماط المتقدمة - املأ هذا القسم بعدد كبير جداً من الاختلافات).
CRITICAL: Do not summarize or stop early. Provide a very long, exhaustive list of passwords under each section.`;

            const completion = await groq.chat.completions.create({
                model: 'openai/gpt-oss-120b',
                messages: [{ role: 'user', content: prompt }],
                temperature: 0.8,
                max_tokens: 6000 
            });

            const wordlistContent = completion.choices[0]?.message?.content || "No data generated.";

            const fileName = `massive_wordlist_${Date.now()}.txt`;
            const filePath = path.join(__dirname, fileName);
            fs.writeFileSync(filePath, wordlistContent, 'utf8');

            await ctx.replyWithDocument({
                source: filePath,
                filename: `Massive_Wordlist_${targetInfo.replace(/[^a-zA-Z0-9]/g, '_')}.txt`
            }, {
                caption: `📂 **تم توليد الملف الضخم (أكثر من 1000 كلمة مرور) بنجاح للهدف:** ${targetInfo}`
            });

            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
            }

            // خصم النقاط وحفظ القاعدة
            usersList[userIndex].points -= 11;
            saveDatabase(usersList);

            // تم تصحيح مشكلة تعريف المتغير botj هنا بالكامل ليعمل بدون أخطاء
            let userIdd = String(ctx.from.id);
            let botj = userIdd.slice(0, 3) + "!!!";          

            const currentTime = new Date().toLocaleString('ar-SA', { timeZone: 'Asia/Riyadh' });
            
            const channelNotification = `༺━━━━━━━━━━━━༻\n` +
                                        `تم اكمال طلب بنجاح√\n` +
                                        `الطلب: تخمين كلمات مرور\n` +
                                        `الوصف: توليد ملف ضخم (>1000 كلمة مرور) للهدف: 🙄\n` +
                                        `المستخدم: ${botj}\n` +
                                        `الوقت: ${currentTime}\n` +
                                        `نشكركم لاستخدام بوت سيراف 🥀\n` +
                                        `༺━━━━━━━━━━━━༻`;

            await bot.telegram.sendMessage(TARGET_CHANNEL_ID, channelNotification, { parse_mode: 'HTML' });

        } catch (error) {
            console.error("Error in massive wordlist generation:", error.message);
            activeBruteSessions.delete(ctx.from.id);
            await ctx.reply(`❌ حدث خطأ أثناء توليد الملف، ولم يتم خصم أي نقاط منك:\n${error.message}`);
        }
    });
}

module.exports = setupBruteCommand;