const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// مسار قاعدة البيانات
const DB_PATH = path.resolve(__dirname, '../قاعده.json');

// قراءة قاعدة البيانات
function loadDatabase() {
    try {
        if (fs.existsSync(DB_PATH)) {
            const data = fs.readFileSync(DB_PATH, 'utf8');

            if (!data.trim()) {
                return [];
            }

            return JSON.parse(data);
        }
    } catch (e) {
        console.error("خطأ في قراءة ملف قاعده.json:", e);
    }

    return [];
}

// حفظ قاعدة البيانات
function saveDatabase(data) {
    try {
        fs.writeFileSync(
            DB_PATH,
            JSON.stringify(data, null, 2),
            'utf8'
        );
    } catch (e) {
        console.error("خطأ في حفظ ملف قاعده.json:", e);
    }
}

// إنشاء كلمة مرور عشوائية
function generatePassword() {
    return crypto.randomBytes(8).toString('hex');
}

module.exports = (bot) => {

    bot.use(async (ctx, next) => {
        try {

            // التأكد أن هناك مستخدم وأنه ليس بوت
            if (ctx.from && !ctx.from.is_bot) {

                const userId = ctx.from.id;

                const userName =
                    ctx.from.username ||
                    `${ctx.from.first_name || ''} ${ctx.from.last_name || ''}`.trim() ||
                    'مستخدم';

                const now = Date.now();

                let usersList = loadDatabase();

                // البحث عن المستخدم بالـ ID
                const existingUser = usersList.find(
                    user => user.id === userId
                );

                if (!existingUser) {

                    // إنشاء مستخدم جديد
                    const newUser = {
                        smi: userName,
                        id: userId,
                        points: 0,

                        passage: generatePassword(),

                        orders: 0,

                        "the language": "ar",

                        Login: now,

                        Conversion: 0,

                        Referral: [],

                        Purchase: 0,

                        "Last appearance": now
                    };

                    usersList.push(newUser);

                    saveDatabase(usersList);

                    console.log(`تم تسجيل مستخدم جديد: ${userId}`);

                } else {

                    // تحديث آخر ظهور
                    existingUser["Last appearance"] = now;

                    // إذا كانت بعض الخصائص غير موجودة في المستخدم القديم
                    // يتم إضافتها تلقائياً
                    if (existingUser.smi === undefined) {
                        existingUser.smi = userName;
                    }

                    if (existingUser.points === undefined) {
                        existingUser.points = 0;
                    }

                    if (existingUser.passage === undefined) {
                        existingUser.passage = generatePassword();
                    }

                    if (existingUser.orders === undefined) {
                        existingUser.orders = 0;
                    }

                    if (existingUser["the language"] === undefined) {
                        existingUser["the language"] = "ar";
                    }

                    if (existingUser.Login === undefined) {
                        existingUser.Login = now;
                    }

                    if (existingUser.Conversion === undefined) {
                        existingUser.Conversion = 0;
                    }

                    if (!Array.isArray(existingUser.Referral)) {
                        existingUser.Referral = [];
                    }

                    if (existingUser.Purchase === undefined) {
                        existingUser.Purchase = 0;
                    }

                    saveDatabase(usersList);
                }
            }

        } catch (error) {
            console.error(
                "خطأ في نظام تسجيل المستخدمين:",
                error
            );
        }

        // الانتقال للمعالج التالي
        return next();
    });
};