const { Markup } = require('telegraf');
const fs = require('fs');
const path = require('path');

const DB_PATH = path.resolve(__dirname, '../قاعده.json');

// قائمة القنوات المطلوبة
const REQUIRED_CHANNELS = [
    '-1004413849148',
    '-1004457851009',
    '-1004316365604',
    '-1003872717957',
    '-1004467417645'
];

// قراءة قاعدة البيانات
function loadDatabase() {
    try {
        if (fs.existsSync(DB_PATH)) {
            const rawData = fs.readFileSync(DB_PATH, 'utf8');
            const data = JSON.parse(rawData);

            // قاعدة البيانات عبارة عن مصفوفة مباشرة
            if (Array.isArray(data)) {
                return data;
            }

            // دعم الشكل القديم
            return Array.isArray(data.users) ? data.users : [];
        }
    } catch (e) {
        console.error("Error reading قاعده.json:", e);
    }

    return [];
}

// حفظ قاعدة البيانات
function saveDatabase(data) {
    try {
        fs.writeFileSync(
            DB_PATH,
            JSON.stringify(data, null, 2),
            'utf8'
        );
    } catch (e) {
        console.error("Error saving قاعده.json:", e);
    }
}

// التحقق من اشتراك المستخدم
async function checkUserSubscriptions(bot, userId) {

    for (const channel of REQUIRED_CHANNELS) {

        try {

            const chatMember =
                await bot.telegram.getChatMember(
                    channel,
                    userId
                );

            const status = chatMember.status;

            if (
                status === 'left' ||
                status === 'kicked'
            ) {
                return false;
            }

        } catch (error) {

            console.error(
                `Error checking subscription for channel ${channel}:`,
                error.message
            );

            return false;
        }
    }

    return true;
}

function setupReferralSystem(bot) {

    // أمر الحصول على رابط الإحالة
    bot.command(
        ['Referral', 'referral', 'احالة', 'إحالة'],
        async (ctx) => {

            try {

                const userId = ctx.from.id;

                const botUsername =
                    ctx.botInfo
                        ? ctx.botInfo.username
                        : (await bot.telegram.getMe()).username;

                const referralLink =
                    `https://t.me/${botUsername}?start=ref_${userId}`;

                const usersList = loadDatabase();

                const userObj =
                    usersList.find(
                        u => u.id === userId
                    );

                const referralCount =
                    userObj
                        ? (userObj.Referral || 0)
                        : 0;

                const message =
                    `🔗 **نظام الإحالة وجمع النقاط**\n\n` +
                    `شارك رابط إحالتك مع أصدقائك واحصل على **30 نقطة** عن كل شخص ينضم عبرك!\n\n` +
                    `📎 **رابطك الخاص:**\n` +
                    `\`${referralLink}\`\n\n` +
                    `👥 عدد الأشخاص الذين دعوتهم: **${referralCount}**`;

                await ctx.reply(
                    message,
                    { parse_mode: 'Markdown' }
                );

            } catch (error) {

                console.error(
                    "Error in /Referral command:",
                    error
                );

                await ctx.reply(
                    "❌ حدث خطأ أثناء إنشاء رابط الإحالة."
                );
            }
        }
    );

    // معالجة start
    bot.command('startt', async (ctx) => {

        try {

            const text = ctx.message.text;
            const parts = text.split(' ');

            if (parts.length > 1) {

                const payload = parts[1];

                if (payload.startsWith('ref_')) {
                    await handleReferral(
                        ctx,
                        bot,
                        payload
                    );

                    return;
                }
            }

            await ctx.reply(
                "👋 مرحباً بك في نظام الإحالة!\n\n" +
                "🔹 للحصول على رابط الإحالة الخاص بك استخدم الأمر: /Referral\n" +
                "🔹 لاستخدام رابط إحالة شخص آخر استخدم: /startt ref_ [رقم المستخدم]"
            );

        } catch (error) {

            console.error(
                "Error in /startt command:",
                error
            );

            await ctx.reply(
                "❌ حدث خطأ. يرجى المحاولة مرة أخرى."
            );
        }
    });

    // معالجة الإحالة
    async function handleReferral(ctx, bot, payload) {

        try {

            if (
                !payload ||
                !payload.startsWith('ref_')
            ) {
                return ctx.reply(
                    "❌ رابط إحالة غير صحيح!"
                );
            }

            const referrerId =
                parseInt(
                    payload.replace('ref_', ''),
                    10
                );

            const newUserId =
                ctx.from.id;

            const newUserFirstName =
                ctx.from.first_name || "مستخدم";

            // منع الإحالة الذاتية
            if (referrerId === newUserId) {

                return ctx.reply(
                    "❌ لا يمكنك استخدام رابط الإحالة الخاص بك!"
                );
            }

            const usersList = loadDatabase();

            // التأكد أن المستخدم غير مسجل
            const existingUser =
                usersList.find(
                    u => u.id === newUserId
                );

            if (existingUser) {

                return ctx.reply(
                    "ℹ️ أنت مسجل بالفعل في النظام."
                );
            }

            // التحقق من الاشتراك
            const isSubscribed =
                await checkUserSubscriptions(
                    bot,
                    newUserId
                );

            if (!isSubscribed) {

                return ctx.reply(
                    "⚠️ **عذراً، لم تتم عملية الإحالة بنجاح!**\n\n" +
                    "يجب عليك أولاً الاشتراك في قنوات البوت المطلوبة لتتمكن من استخدام الرابط والحصول على المكافأة.",
                    Markup.inlineKeyboard([
                        [
                            Markup.button.url(
                                '📢 قناة البوت الأولى',
                                'https://t.me/Alnaqchannel'
                            )
                        ],
                        [
                            Markup.button.url(
                                '📢 قناة البوت الثانية',
                                'https://t.me/thechanneldeletedi'
                            )
                        ]
                    ])
                );
            }

            // البحث عن صاحب رابط الإحالة
            const referrerIndex =
                usersList.findIndex(
                    u => u.id === referrerId
                );

            // إذا صاحب الرابط غير موجود
            if (referrerIndex === -1) {

                usersList.push({
                    smi: newUserFirstName,
                    id: newUserId,
                    points: 0,
                    passage: '',
                    orders: 0,
                    "the language": "ar",
                    Login: Date.now(),
                    Conversion: 0,
                    Referral: 0,
                    Purchase: 0,
                    "Last appearance": Date.now()
                });

                saveDatabase(usersList);

                return ctx.reply(
                    "🎉 أهلاً بك في البوت!"
                );
            }

            // إضافة المستخدم الجديد
            usersList.push({
                smi: newUserFirstName,
                id: newUserId,
                points: 0,
                passage: '',
                orders: 0,
                "the language": "ar",
                Login: Date.now(),
                Conversion: 0,
                Referral: 0,
                Purchase: 0,
                "Last appearance": Date.now()
            });

            // إضافة 30 نقطة لصاحب الإحالة
            usersList[referrerIndex].points =
                (usersList[referrerIndex].points || 0) + 30;

            // ==========================================
            // زيادة Referral لصاحب رابط الإحالة
            // ==========================================

            if (
                typeof usersList[referrerIndex].Referral !== 'number'
            ) {
                usersList[referrerIndex].Referral = 0;
            }

            usersList[referrerIndex].Referral += 1;

            // حفظ البيانات
            saveDatabase(usersList);

            // رسالة للمستخدم الجديد
            await ctx.reply(
                "🎉 أهلاً بك! تم تسجيل دخولك عبر رابط دعوة بنجاح."
            );

            // إشعار صاحب الإحالة
            try {

                await bot.telegram.sendMessage(
                    referrerId,
                    `🎉 **مبروك! لقد انضم شخص جديد عبر رابط إحالتك.**\n` +
                    `💎 تم إضافة **30 نقطة** إلى رصيدك!\n` +
                    `👥 عدد إحالاتك الآن: **${usersList[referrerIndex].Referral}**`
                );

            } catch (_) {}

        } catch (error) {

            console.error(
                "Error processing referral:",
                error
            );

            await ctx.reply(
                "❌ حدث خطأ أثناء معالجة الإحالة."
            );
        }
    }
}

module.exports = setupReferralSystem;