// دن تم التطوير بواسطه داكس المظ🐦مطور بوت سيراف
// لا تحذف السطرين دول بل حب😭🗿

const { Telegraf, Markup } = require('telegraf');
const fs = require('fs');
const path = require('path');

// ضع توكن البوت الخاص بك هنا (يرجى تغييره من BotFather لأنه أصبح مكشوفاً)
const BOT_TOKEN = '8809982828:AAFwqgU5lup25zSjH5HPAENPU4A2N87Gj5E';

const bot = new Telegraf(BOT_TOKEN);

// آيديهات القنوات الإجبارية والروابط الخاصة بها (تم التعديل وإضافة القناة الجديدة)
const CHANNELS_TO_CHECK = [
    { 
        id: '-1004413849148', 
        link: 'https://t.me/Alnaqchannel', 
        name: 'سيراف|points ' 
    },
    { 
        id: '-1004316365604', 
        link: 'https://t.me/officialshippingguideis', 
        name: 'دليل الشحن' 
    },
    { 
        id: '-1003872717957', 
        link: 'https://t.me/strongestchannelforupdate', 
        name: 'تحديثات بوت سيراف' 
    },
    {
        id: '-1004457851009',
        link: 'https://t.me/dhdbbfbg',
        name: 'اكتمال الطلبات'
    }
];

// دالة فحص اشتراك المستخدم في القنوات بالآيدي الرقمي
async function checkUserSubscription(botInstance, userId) {
    for (let item of CHANNELS_TO_CHECK) {
        try {
            const chatMember = await botInstance.telegram.getChatMember(item.id, userId);
            const status = chatMember.status;
            
            if (status === 'left' || status === 'kicked') {
                return false;
            }
        } catch (error) {
            console.log(`Check sub error for channel ${item.id}:`, error.message);
            return false;
        }
    }
    return true;
}

// دالة إرسال رسالة طلب الاشتراك الإجباري في القنوات (تم التعديل لتصبح ديناميكية)
async function sendForceSubMessage(ctx) {
    // بناء الأزرار تلقائياً من مصفوفة القنوات
    const buttons = CHANNELS_TO_CHECK.map(channel => [
        Markup.button.url(channel.name, channel.link)
    ]);
    
    // إضافة زر التحقق في النهاية
    buttons.push([Markup.button.callback('التحقق من الاشتراك√', 'check_subscription')]);

    const keyboard = Markup.inlineKeyboard(buttons);

    return ctx.reply(
        `❗ عذرا عزيزي عليك الاشتراك في القنوات التالية لتستخدم البوت:`,
        { ...keyboard }
    );
}

// اعتراض الرسائل والأوامر لفحص الاشتراك (فقط في الشات الخاص بين البوت والمستخدم)
bot.use(async (ctx, next) => {
    try {
        if (!ctx.from) return next();
        
        // استثناء الأزرار التفاعلية
        if (ctx.callbackQuery) return next();

        // تطبيق الاشتراك الإجباري فقط إذا كانت المحادثة خاصة (Private Chat) وليست قروباً أو قناة
        if (ctx.chat && ctx.chat.type === 'private') {
            const userId = ctx.from.id;
            const isSubscribed = await checkUserSubscription(bot, userId);

            if (!isSubscribed) {
                return sendForceSubMessage(ctx);
            }
        }

        return next();
    } catch (err) {
        console.error("Error in force sub middleware:", err);
        return next();
    }
});

// معالجة زر "التحقق من الاشتراك√"
bot.action('check_subscription', async (ctx) => {
    try {
        const userId = ctx.from.id;
        const isSubscribed = await checkUserSubscription(bot, userId);

        if (isSubscribed) {
            await ctx.deleteMessage().catch(() => {});
            await ctx.reply(`✅ تم التحقق من اشتراكك! يمكنك الان استخدام البوت.`);
        } else {
            await ctx.answerCbQuery('❌ أنت لست مشترك في جميع القنوات بعد!', { show_alert: true });
        }
    } catch (error) {
        console.error("Error in check_subscription action:", error);
    }
});

// مسار مجلد الأوامر وتحميلها تلقائياً
const bothDir = path.join(__dirname, 'both');

if (fs.existsSync(bothDir)) {
    fs.readdirSync(bothDir).forEach((file) => {
        if (file.endsWith('.js')) {
            const filePath = path.join(bothDir, file);
            const commandModule = require(filePath);

            if (typeof commandModule === 'function') {
                commandModule(bot);
                console.log(`[تم التحميل]: تم تفعيل ملف الأوامر -> ${file}`);
            }
        }
    });
}

// تشغيل البوت
bot.launch().then(() => {
    console.log('تم تشغيل البوت بنجاح...');
});

// إيقاف آمن للبوت
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));